# ----------------------------------------------------------------------------------------------------------------------
# COPYRIGHT 2017 ESRI
#
# TRADE SECRETS: ESRI PROPRIETARY AND CONFIDENTIAL
# Unpublished material - all rights reserved under the
# Copyright Laws of the United States.
#
# For additional information, contact:
# Environmental Systems Research Institute, Inc.
# Attn: Contracts Dept
# 380 New York Street
# Redlands, California, USA 92373
#
# email: contracts@esri.com
# ----------------------------------------------------------------------------------------------------------------------

# ----------------------------------------------------------------------------------------------------------------------
# Usage notes
# CreateLowAndHighSpots_defense(Input_Area_of_Interest, Input_Rasters;Input_Rasters...,
# Input_Spot_Height_Features, {Spot_Height_Subtype})
#
# INDEX, NAME, DISPLAY NAME, PARAMETER TYPE, MULTIVALUE, DATA TYPE, DIRECTION, DEPENDENCIES, VALUE
# {0}, Input_Area_of_Interest, Input Area of Interest, Required, False, Feature Layer, Input, [], None
# {1}, Input_Rasters, Input Rasters, Required, True, Raster Layer, Input, [], None
# {2}, Input_Spot_Height_Features, Input Spot Height Features, Required, False, Feature Layer, Input, [], None
# {3}, Spot_Height_Subtype, Spot Height Subtype, Optional, False, String, Input, [], None
# {4}, Output_Spot_Height_Features, Output Spot Height Features, Derived, False, Feature Layer, Output, [2], None
# ---------------------------------------------------------------------------------------------------------------------

# Setting variable for script name
THIS_FILE_NAME = 'CreateLowHighSpots.py'


# Testing AOI for selection
def testaoi(inputaoi):
    from arcpy import mapping
    lay = mapping.Layer(inputaoi)
    sel = lay.getSelectionSet()
    count = len(sel)
    if not count > 0:
        raise Exception('The AOI must have at least one feature selected.')
    return


# Create Mosaic
def mosaic(inrasters, temp, temporaryfcs):
    from arcpy import management
    from DefenseUtilities import GetRasterProperties
    inrasters = inrasters.split(';')
    if len(inrasters) > 1:
        rasterprops = GetRasterProperties(inrasters)
        bands = rasterprops.bands
        pixeltype = rasterprops.pixelType
        rasterstring = ''
        for raster in inrasters:
            rasterstring += r'{0};'.format(raster)
        inputraster = management.MosaicToNewRaster(rasterstring, temp, 'SPOT_Raster.tif', '#', pixeltype,
                                                   '#', bands, 'MEAN', 'FIRST').getOutput(0)
        temporaryfcs.append(inputraster)
    else:
        from string import strip
        inputraster = r'{0}'.format(strip(inrasters[0], "'"))
    return inputraster


# Add Fields to temp features
def addfields(features):
    from arcpy import management
    for feature in features:
        management.AddField(feature, 'ESC', 'LONG')
        management.CalculateField(feature, 'ESC', 1, 'PYTHON')
        management.AddField(feature, 'ACC', 'LONG')
        management.CalculateField(feature, 'ACC', 1, 'PYTHON')
    return


# Create field Mapping
def fieldmappings(spotsubtype, highpoints, lowpoints):
    lowmapping = ''
    if spotsubtype == 'SPOT_ELEVATION_P':
        highmapping = 'ESC "Elevation Surface Category" true true false 4 Long 0 0 ,First,#,' + \
                      '{0},ESC,-1,-1;ZVH "Highest Elevation" true false false 8 Double 0 0 ,'.format(highpoints) + \
                      'First,#,{0},GRID_CODE,-1,-1'.format(highpoints)
        lowmapping = 'ESC "Elevation Surface Category" true true false 4 Long 0 0 ,First,#,'.format(lowpoints) + \
                     '{0},ESC,-1,-1;ZVH "Highest Elevation" true false false 8 Double 0 0 ,'.format(lowpoints) + \
                     'First,#,{0},GRID_CODE,-1,-1'.format(lowpoints)
    elif spotsubtype == 'CA030_Spot_Elevation_Point':
        highmapping = 'ELA "Elevation Accuracy Category" true true false 4 Long 0 0 ,First,#,' + \
                      '{0},ESC,-1,-1;ZVH "Highest Elevation" true false false 8 Double 0 0 ,'.format(highpoints) + \
                      'First,#,{0},GRID_CODE,-1,-1;ACC "Horizontal Accuracy Category" '.format(highpoints) + \
                      'true true false 4 Long 0 0 ,First,#,{0},ACC,-1,-1'.format(highpoints)
        lowmapping = 'ELA "Elevation Accuracy Category" true true false 4 Long 0 0 ,First,#,' + \
                     '{0},ESC,-1,-1;ZVH "Highest Elevation" true false false 8 Double 0 0 ,'.format(lowpoints) + \
                     'First,#,{0},GRID_CODE,-1,-1;ACC "Horizontal Accuracy Category" true true '.format(lowpoints) + \
                     'false 4 Long 0 0 ,First,#,{0},ACC,-1,-1'.format(lowpoints)
    elif spotsubtype == 'CA030 - Spot Elevation Point':
        highmapping = 'ELA "Elevation Accuracy Category" true true false 4 Long 0 0 ,First,#,' + \
                      '{0},ESC,-1,-1;ZVH "Highest Elevation" true false false 8 Double 0 0 ,First,#,'.format(highpoints) + \
                      '{0},GRID_CODE,-1,-1;ACC "Horizontal Accuracy Category" true true false 4 '.format(highpoints) + \
                      'Long 0 0 ,First,#,{0},ACC,-1,-1'.format(highpoints)
        lowmapping = 'ELA "Elevation Accuracy Category" true true false 4 Long 0 0 ,First,#,' + \
                     '{0},ESC,-1,-1;ZVH "Highest Elevation" true false false 8 Double 0 0 ,First,#,'.format(lowpoints) + \
                     '{0},GRID_CODE,-1,-1;ACC "Horizontal Accuracy Category" true true false 4 Long'.format(lowpoints) + \
                     '0 0 ,First,#,{0},ACC,-1,-1'.format(lowpoints)
    elif spotsubtype == 'SpotElevationPoint':
        highmapping = 'ELA "ela" true true false 4 Long 0 0 ,First,#,{0},ESC,-1,-1;ZV2 "zv2"'.format(highpoints) + \
                      'true false false 8 Double 0 0 ,First,#,{0},GRID_CODE,-1,-1;ACC "acc" true'.format(highpoints) + \
                      'true false 4 Long 0 0 ,First,#,{0},ACC,-1,-1'.format(highpoints)
    else:
        highmapping = 'ESC "Elevation Surface Category" true true false 4 Long 0 0 ,First,#,' + \
                      '{0},ESC,-1,-1;ZVH "Highest Elevation" true false false 8 Double 0 0 ,First,'.format(highpoints) + \
                      '#,{0},GRID_CODE,-1,-1'.format(highpoints)
        lowmapping = 'ESC "Elevation Surface Category" true true false 4 Long 0 0 ,First,#,' + \
                     '{0},ESC,-1,-1;ZVH "Highest Elevation" true false false 8 Double 0 0 ,'.format(lowpoints) + \
                     'First,#,{0},GRID_CODE,-1,-1'.format(lowpoints)
    return highmapping, lowmapping


# Creates low and high spots for each selected AOI
def processspots(temp, tempfcs, aoi, inraster, spots, subtype, scratch):
    from arcpy import management, sa, da, gp, conversion, SearchCursor, mapping, AddMessage, Describe
    from os import path
    try:
        lay = mapping.Layer(aoi)
        oIDs = lay.getSelectionSet()
        for oID in oIDs:
            currentaoi = management.MakeFeatureLayer(aoi, 'currentAOI', "(OBJECTID = {0})".format(str(oID)))
            exportaoi = management.CopyFeatures(currentaoi, path.join(temp, 'Export_AOI.shp')).getOutput(0)
            tempfcs.append(exportaoi)
            desc = Describe(inraster)
            rasterformat = desc.format
            clippedraster = management.Clip(inraster, '#', path.join(temp, 'Clipped_Raster.tif'),
                                            exportaoi, '-32767', 'ClippingGeometry').getOutput(0)
            if rasterformat == 'GRID':
                clippedraster = management.CopyRaster(clippedraster, path.join(scratch, 'Clipped_Raster'),
                                                            '#', '#', '#', 'NONE', 'NONE', '16_BIT_SIGNED', 'NONE',
                                                            'NONE').getOutput(0)

            intraster = sa.Int(clippedraster)
            intraster.save(path.join(temp, 'intraster'))
            tempfcs.append(intraster)
            tempfcs.append(path.join(temp, 'intraster'))

            tempfcs.append(clippedraster)
            raster = sa.Raster(path.join(temp, 'intraster'))
            filteredraster = sa.SetNull(raster == 0, raster)

            highvalue = str(management.GetRasterProperties(filteredraster, "MAXIMUM").getOutput(0))
            lowvalue = str(management.GetRasterProperties(filteredraster, "MINIMUM").getOutput(0))
            cellsize = str(management.GetRasterProperties(filteredraster, "CELLSIZEX").getOutput(0))

            highvalueraster = gp.CreateConstantRaster(path.join(scratch, 'highraster'), highvalue, 'INTEGER', cellsize, clippedraster).getOutput(0)
            lowvalueraster = gp.CreateConstantRaster(path.join(scratch, 'lowraster'), lowvalue, 'INTEGER', cellsize, clippedraster).getOutput(0)

            highcellsraster = sa.Con(filteredraster == highvalueraster, filteredraster)
            lowcellsraster = sa.Con(filteredraster == lowvalueraster, filteredraster)
            highpoints = conversion.RasterToPoint(highcellsraster, path.join(temp, 'HighPoints.shp'), 'Value').getOutput(0)
            tempfcs.append(highpoints)
            lowpoints = conversion.RasterToPoint(lowcellsraster, path.join(temp, 'LowPoints.shp'), 'Value').getOutput(0)
            tempfcs.append(lowpoints)
            addfields([highpoints, lowpoints])
            highmapping, lowmapping = fieldmappings(subtype, highpoints, lowpoints)
            highpointslayer = management.MakeFeatureLayer(highpoints, 'highPoints')
            if int(management.GetCount(highpointslayer).getOutput(0)) == 1:
                management.Append(highpointslayer, spots, 'NO_TEST', highmapping, subtype)
            else:
                cur = SearchCursor(highpointslayer)
                row = cur.next()
                if row is not None:
                    fid = str(row.FID)
                    management.SelectLayerByAttribute(highpointslayer, 'NEW_SELECTION', '(FID = {0})'.format(fid))
                    management.Append(highpointslayer, spots, 'NO_TEST', highmapping, subtype)
                del row
                del cur
            lowpointslayer = None
            if subtype != 'SpotElevationPoint':
                lowpointslayer = management.MakeFeatureLayer(lowpoints, 'lowPoints')
                if int(management.GetCount(lowpointslayer).getOutput(0)) == 1:
                    management.Append(lowpointslayer, spots, 'NO_TEST', lowmapping, subtype)
                else:
                    cur = SearchCursor(lowpointslayer)
                    row = cur.next()
                    if row is not None:
                        fid = str(row.FID)
                        management.SelectLayerByAttribute(lowpointslayer, 'NEW_SELECTION', '(FID = {0})'.format(fid))
                        management.Append(lowpointslayer, spots, 'NO_TEST', lowmapping, subtype)
                    del row
                    del cur
            try:
                management.Delete(currentaoi)
                management.Delete(exportaoi)
                management.Delete(highpointslayer)
                if lowpointslayer is not None:
                    management.Delete(lowpointslayer)
                del exportaoi
                del clippedraster
                del raster
                del highpoints
                del lowpoints
            except Exception as e:
                from arcpy import AddWarning
                AddWarning('Unable to delete variables or temporary layers.\n{0}'.format(e))
        return
    except Exception as e:
        from arcpy import AddError
        from DefenseUtilities import trace
        line, filename, err = trace(THIS_FILE_NAME)
        AddError('Geoprocessing error on {0} of {1} :\n{2}\n{3}'.format(line, filename, err, e))


# Main execution
def main():
    from arcpy import GetParameterAsText
    from DefenseUtilities import checkoutextensions, setenvironment
    try:
        checkoutextensions(['defense', 'spatial'])
        scratch, temp, temporaryfcs = setenvironment()
        testaoi(GetParameterAsText(0))
        inputraster = mosaic(GetParameterAsText(1), temp, temporaryfcs)
        processspots(temp, temporaryfcs, GetParameterAsText(0), inputraster, GetParameterAsText(2),
                     GetParameterAsText(3), scratch)
    except Exception as e:
        from arcpy import AddError
        from DefenseUtilities import trace
        line, filename, err = trace(THIS_FILE_NAME)
        AddError('Geoprocessing error on {0} of {1} :\n{2}\n{3}'.format(line, filename, err, e))
    finally:
        from arcpy import management, Exists
        from os import path
        from shutil import rmtree
        try:
            copytemporaryfcs = temporaryfcs[:]
            for temp in copytemporaryfcs:
                if Exists(temp):
                    management.Delete(temp)
                    temporaryfcs.remove(temp)
            del copytemporaryfcs
        except Exception as e:
            pass
        try:
            folder = path.split(scratch)[0]
            rmtree(folder, True)
        except Exception as e:
            pass

# Run main
if __name__ == '__main__':
    main()
