# ----------------------------------------------------------------------------------------------------------------------
# COPYRIGHT 2017 ESRI
#
# TRADE SECRETS: ESRI PROPRIETARY AND CONFIDENTIAL
# Unpublished material - all rights reserved under the
# Copyright Laws of the United States.
#
# For additional information, contact:
# Environmental Systems Research Institute, Inc.
# Attn: Contracts Dept
# 380 New York Street
# Redlands, California, USA 92373
#
# email: contracts@esri.com
# ----------------------------------------------------------------------------------------------------------------------

# ----------------------------------------------------------------------------------------------------------------------
# Usage notes
# SimplifyContours_defense(Input_Contours, 1:50000 | 1:5000 | 1:7500 | 1:12500 | 1:25000 | 1:100000 | 1:250000 | 1:500000 | 1:1000000)
#
# INDEX, NAME, DISPLAY NAME, PARAMETER TYPE, MULTIVALUE, DATA TYPE, DIRECTION, DEPENDENCIES, VALUE
# {0}, Input_Contours, Input Contours, Required, False, Feature Layer, Input, [], None
# {1}, Scale, Scale, Required, False, String, Input, [], 1:50000
# {2}, Output_Contours, Output Contours, Derived, False, Feature Layer, Output, [0], None
# ----------------------------------------------------------------------------------------------------------------------

# Creating file name variable
THIS_FILE_NAME = 'SimplifyContours.py'


# Getting smooting tolerances based on scale
def gettolerance(scale):
    from DefenseUtilities import GetContourTolerances
    tol = GetContourTolerances(scale)
    tolerance = tol.tolerance
    return tolerance


# Simplifying line
def ProcessFeatures(contours, tempsimplifyspace, tempsmoothspace, simplifyTolerance, smoothTolerance):
    from arcpy import AddMessage, cartography, management, SetParameter
    
    AddMessage('Removing extraneous points...')
    cartography.SimplifyLine(contours, tempsimplifyspace, 'POINT_REMOVE', simplifyTolerance, 'FLAG_ERRORS', 'NO_KEEP', 'NO_CHECK')
    management.DeleteFeatures(contours)
    
    AddMessage('Smoothing sharp angles...')
    cartography.SmoothLine(tempsimplifyspace, tempsmoothspace, 'PAEK', smoothTolerance)
    management.DeleteFeatures(tempsimplifyspace)
    
    AddMessage('Appending features to {0}...'.format(contours))
    management.Append(tempsmoothspace, contours, 'NO_TEST')
    SetParameter(2, contours)
    return


# Runs simplify operation
def Process(inputcontours, scale, scratch):
    from DefenseUtilities import GetContourTolerances
    tol = GetContourTolerances(scale)
    
    ProcessFeatures(inputcontours, r'{0}\Temp_Simplify'.format(scratch), r'{0}\Temp_Smooth'.format(scratch), tol.simplifyTolerance, tol.smoothTolerance)
    return


# Main execution
def main():
    from arcpy import GetParameterAsText
    from DefenseUtilities import checkoutextensions, setenvironment
    try:
        checkoutextensions(['defense'])
        scratch = setenvironment()[0]
        Process(GetParameterAsText(0), GetParameterAsText(1), scratch)
    except Exception as e:
        from arcpy import AddError
        from DefenseUtilities import trace
        line, filename, err = trace(THIS_FILE_NAME)
        AddError('Geoprocessing error on {0} of {1} :\n{2}\n{3}'.format(line, filename, err, e))
    finally:
        from os import path
        from shutil import rmtree
        try:
            folder = path.split(scratch)[0]
            rmtree(folder, True)
        except:
            pass

# Run main
if __name__ == '__main__':
    main()
