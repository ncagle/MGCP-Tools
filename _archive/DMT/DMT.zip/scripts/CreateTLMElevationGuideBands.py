# ----------------------------------------------------------------------------------------------------------------------
# COPYRIGHT 2017 ESRI
#
# TRADE SECRETS: ESRI PROPRIETARY AND CONFIDENTIAL
# Unpublished material - all rights reserved under the
# Copyright Laws of the United States.
#
# For additional information, contact:
# Environmental Systems Research Institute, Inc.
# Attn: Contracts Dept
# 380 New York Street
# Redlands, California, USA 92373
#
# email: contracts@esri.com
# ----------------------------------------------------------------------------------------------------------------------

# ----------------------------------------------------------------------------------------------------------------------
# Usage notes
# CreateTLMElevationGuideBands_defense(AOI_Feature_Class, AOI_Field, AOI_Buffer, Contour_Features,
# 20 | 10 | 40 | 80, Elevation_Field_Name, METERS | FEET, NO_CHOOSE_BANDS | CHOOSE_BANDS,
# {2 | 3 | 4}, Output_Feature_Class, {Additional_Elevation_Features;Additional_Elevation_Features...},
# {Exclusion_Features;Exclusion_Features...})
#
# INDEX, NAME, DISPLAY NAME, PARAMETER TYPE, MULTIVALUE, DATA TYPE, DIRECTION, DEPENDENCIES, VALUE
# {0}, AOI_Feature_Class, AOI Feature Class, Required, False, Feature Layer, Input, [], None
# {1}, AOI_Field, AOI Field, Required, False, Field, Input, [0], None
# {2}, AOI_Buffer, AOI Buffer, Required, False, Linear unit, Input, [], 0 Meters
# {3}, Contour_Features, Contour Features, Required, False, Feature Layer, Input, [], None
# {4}, Contour_Interval, Contour Interval, Required, False, Long, Input, [], 20
# {5}, Elevation_Field_Name, Elevation Field Name, Required, False, Field, Input, [3], None
# {6}, Elevation_Units, Elevation Units, Required, False, String, Input, [], Meters
# {7}, Choose_Number_of_Bands, Choose Number of Bands, Required, False, Boolean, Input, [], False
# {8}, Number_of_Bands, Number of Bands, Optional, False, Double, Input, [], 2.0
# {9}, Output_Feature_Class, Output Feature Class, Required, False, Feature Class, Output, [], None
# {10}, Additional_Elevation_Features, Additional Elevation Features, Optional, True, Feature Layer, Input, [], None
# {11}, Exclusion_Features, Exclusion Features, Optional, True, Feature Layer, Input, [], None
# ----------------------------------------------------------------------------------------------------------------------

# Importing necessary modules
from arcpy import AddError, management, da, analysis, AddMessage, production, SetParameter, AddWarning, GetParameterAsText
from DefenseUtilities import writeresults, trace, checkoutextensions, setenvironment
from shutil import rmtree
from sys import exit
from os import path

# Naming the file for error reporting purposes
THIS_FILE_NAME = 'CreateTLMElevationGuideBands.py'


# Setting temp features
def settempfeatures(scratch, tempfolder):
    numericaoifc = path.join(scratch, 'numAOI')
    eraseaoifc = path.join(scratch, 'eraseAOI')
    join = path.join(scratch, 'spatialJoin')
    bandsaoi = path.join(tempfolder, 'bandsAOI')
    bandsfc = path.join(scratch, 'bandsFC')
    templist = [numericaoifc, eraseaoifc, join, bandsaoi, bandsfc]
    return templist, numericaoifc, eraseaoifc, join, bandsaoi, bandsfc


# Setting variables for band values
def setbandvalues(choosebands, numberofbands):
    diff_boundary_values = [50, 100, 300, 600, 1200]
    range_count_defs = [[10, [1, 2, 3, 4, 4, 4]], [20, [1, 2, 3, 3, 4, 4]], [40, [1, 1, 2, 3, 4, 4]], [80, [1, 1, 2, 3, 4, 4]]]
    area_ranges_names = []
    area_ranges = []
    if choosebands == 'true':
        if numberofbands == 2:
            area_ranges_names = ['Low', 'High']
            area_ranges = [[100, 0], [60, 40], [40, 60], [30, 70]]
        elif numberofbands == 3:
            area_ranges_names = ['Low', 'Medium', 'High']
            area_ranges = [[100, 0, 0], [60, 0, 40], [30, 40, 30], [20, 40, 40]]
        elif numberofbands == 4:
            area_ranges_names = ['Low', 'Medium', 'High', 'Highest']
            area_ranges = [[100, 0, 0, 0], [60, 0, 40, 0], [30, 40, 30, 0], [20, 30, 30, 20]]
    else:
        numberofbands = 4
        area_ranges_names = ['Low', 'Medium', 'High', 'Highest']
        area_ranges = [[100, 0, 0, 0], [60, 0, 40, 0], [30, 40, 30, 0], [20, 30, 30, 20]]
    return diff_boundary_values, range_count_defs, area_ranges_names, area_ranges, numberofbands


# Calculate contour interval index to check parameter
def calccontourindex(range_count_defs, contourinterval):
    contour_interval_index = 1
    for range_def_index in xrange(0, len(range_count_defs)):
        if contourinterval == range_count_defs[range_def_index][0]:
            contour_interval_index = range_def_index
            break
    if contour_interval_index == -1:
        AddError('Incorrect contour interval defined.')
        exit()
    return contour_interval_index


# Creating temp AOI for processing
def createtempaoi(aoifeatures, numericaoifc):
    management.CopyFeatures(aoifeatures, numericaoifc)
    writeresults()
    management.AddField(numericaoifc, 'TempID', 'LONG')
    writeresults()
    aoicount = int(str(management.GetCount(numericaoifc)))
    writeresults()
    return aoicount


# Get update cursor to count features
def updatecount(numericaoifc):
    with da.UpdateCursor(numericaoifc, 'TempID') as cur:
        index = 0
        for row in cur:
            index += 1
            row[0] = index
            cur.updateRow(row)
    return numericaoifc


# Erase exclusion areas from the temp AOI
def erase(numericaoifc, exclusionfeatures, eraseaoifc):
    lasterase = numericaoifc
    exclusionfeatureclasses = exclusionfeatures.split(';')
    for exclusion in exclusionfeatureclasses:
        if len(exclusion) != 0:
            exclusion = exclusion.strip("'")
            analysis.Erase(numericaoifc, exclusion, eraseaoifc)
            writeresults()
            lasterase = eraseaoifc
            numericaoifc, eraseaoifc = eraseaoifc, numericaoifc
    return lasterase


# Spatial Join
def spatialjoin(contourfeatures, lasterase, join, elevationfield):
    analysis.SpatialJoin(contourfeatures, lasterase, join, 'JOIN_ONE_TO_MANY', 'KEEP_COMMON', 'Elevation "Elevation" true true false 19' +
                         'Double 0 0 ,First,#,{0},{1},-1,-1;TempID "TempID" true true false 9 Long 0 9 ,First,#,{2},TempID,-1,-1'.format(contourfeatures, elevationfield, lasterase),
                         'INTERSECTS', '#', '#')
    writeresults()
    return join


# Creating bands
def band(aoicount, join, diffboundvalues, contindex, rangecdefs, ranges, numberofbands, rangesnames, lastrase, bandsaoi,
         contours, elevfield, elevunits, addelevation, bandsfc, aoifield, aoibuffer, exfeatures, outbands,
         continterval):
    outputbandfcinit = 0
    for index in xrange(1, aoicount + 1):
        elev_max = 0
        elev_min = 0
        with da.SearchCursor(join, ['TempID', 'Elevation'], 'TempID = {}'.format(index)) as cur:
            for row in cur:
                elevation = row[1]
                elev_max = elevation
                elev_min = elevation
        with da.SearchCursor(join, ['TempID', 'Elevation'], 'TempID = {}'.format(index)) as cur:
            for row in cur:
                elevation = row[1]
                if elevation < elev_min:
                    elev_min = elevation
                if elevation > elev_max:
                    elev_max = elevation
        elev_diff = elev_max - elev_min
        AddMessage('Max Elevation: {}; Min Elevation: {}'.format(elev_max, elev_min))
        range_index = 0
        for range_boundary in diffboundvalues:
            if elev_diff <= range_boundary:
                break
            range_index += 1
        range_count = rangecdefs[contindex][1][range_index]
        area_range = ranges[range_count - 1]
        AddMessage('AOI: {}; Difference: {} m; Count: {} --> {}'.format(index, elev_diff, range_count, area_range))
        area_low_boundary = 0
        bands_ranges_definition = ''
        for area_index in xrange(0, numberofbands):
            range_length = area_range[area_index]
            assert range_length >= 0
            if range_length == 0:
                continue
            area_high_boundary = area_low_boundary + area_range[area_index]
            assert area_high_boundary <= 100
            if bands_ranges_definition != '':
                bands_ranges_definition += ';'
            bands_ranges_definition += '{} {} {}'.format(area_low_boundary, area_high_boundary, rangesnames[area_index])
            area_low_boundary = area_high_boundary
        assert area_high_boundary == 100
        management.MakeFeatureLayer(lastrase, bandsaoi, 'TempID = {}'.format(index))
        writeresults()
        management.SaveToLayerFile(bandsaoi, bandsaoi)
        writeresults()
        inelevationfeatures = "'{}' {} {}".format(contours, elevfield, elevunits)
        elevfcs = addelevation.split(';')
        for elevFC in elevfcs:
            if len(elevFC) != 0:
                if len(inelevationfeatures) > 0:
                    inelevationfeatures += ';'
                inelevationfeatures += '{} {} {}'.format(elevFC, elevfield, elevunits)
        production.BandsFromFeatures(inelevationfeatures, elevunits, bandsfc, 'PERCENTILE_VALUE',
                                     bands_ranges_definition, bandsaoi, aoifield, aoibuffer, exfeatures,
                                     'INTERPOLATE', '3', '1', 'NO_REFINE_ELEVATION_MODEL', '#', '#', '#')
        writeresults()
        calculated_bands = int(str(management.GetCount(bandsfc)))
        if calculated_bands == 0 and outputbandfcinit:
            AddWarning('No bands have been calculated for this AOI')
            continue
        AddMessage('Calculated bands count: {}'.format(calculated_bands))
        management.AddField(bandsfc, 'Interval', 'LONG')
        writeresults()
        management.CalculateField(bandsfc, 'Total_Bands', str(range_count), 'PYTHON')
        management.CalculateField(bandsfc, 'Interval', str(continterval), 'PYTHON')
        if not outputbandfcinit:
            management.CopyFeatures(bandsfc, outbands)
            outputbandfcinit = 1
        else:
            management.Append(bandsfc, outbands, 'TEST')
    SetParameter(9, outbands)
    return


# Main execution
def main():
    try:
        checkoutextensions(['foundation', 'defense'])
        scratch, tempfolder, templist = setenvironment()
        templist, numericaoifc, eraseaoifc, spajoin, bandsaoi, bandsfc = settempfeatures(scratch, tempfolder)
        diff_boundary_values, range_count_defs, area_ranges_names, area_ranges, numberofbands = setbandvalues(
            GetParameterAsText(7), int(GetParameterAsText(8)))
        contour_interval_index = calccontourindex(range_count_defs, GetParameterAsText(4))
        aoicount = createtempaoi(GetParameterAsText(0), numericaoifc)
        numericaoifc = updatecount(numericaoifc)
        lasterase = erase(numericaoifc, GetParameterAsText(11), eraseaoifc)
        spajoin = spatialjoin(GetParameterAsText(3), lasterase, spajoin, GetParameterAsText(5))
        band(aoicount, spajoin, diff_boundary_values, contour_interval_index, range_count_defs, area_ranges,
             numberofbands, area_ranges_names, lasterase, bandsaoi, GetParameterAsText(3),
             GetParameterAsText(5), GetParameterAsText(6).upper(), GetParameterAsText(10), bandsfc,
             GetParameterAsText(1), GetParameterAsText(2).upper(), GetParameterAsText(11), GetParameterAsText(9),
             GetParameterAsText(4))
    except Exception as e:
        line, filename, err = trace(THIS_FILE_NAME)
        AddError('Geoprocessing error on {} of {} :\n{}'.format(line, filename, err, e))
    finally:
        try:
            folder = path.split(scratch)[0]
            rmtree(folder, True)
        except Exception as e:
            pass


# Run main
if __name__ == '__main__':
    main()
