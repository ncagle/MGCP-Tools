# COPYRIGHT 2017 ESRI
#
# TRADE SECRETS: ESRI PROPRIETARY AND CONFIDENTIAL
# Unpublished material - all rights reserved under the
# Copyright Laws of the United States.
#
# For additional information, contact:
# Environmental Systems Research Institute, Inc.
# Attn: Contracts Dept
# 380 New York Street
# Redlands, California, USA 92373
#
# email: contracts@esri.com

#-------------------------------------------------------------------------------
# Usage notes
# GeodatabaseCompare_defense(Base_Geodatabase, Test_Geodatabase, Sort_Field,
# ALL | GEOMETRY_ONLY | ATTRIBUTES_ONLY | SCHEMA_ONLY | SPATIAL_REFERENCE_ONLY, Output_File,
# {IGNORE_M | IGNORE_Z | IGNORE_POINTID | IGNORE_EXTENSION_PROPERTIES | IGNORE_SUBTYPES |
# IGNORE_RELATIONSHIPCLASSES | IGNORE_REPRESENTATIONCLASSES}, {NO_CONTINUE_COMPARE | CONTINUE_COMPARE},
# {NOT_ERRORS_ONLY | ERRORS_ONLY})
#
# INDEX, NAME, DISPLAY NAME, PARAMETER TYPE, MULTIVALUE, DATA TYPE, DIRECTION, DEPENDENCIES, VALUE
# {0}, Base_Geodatabase, Base Geodatabase, Required, False, Workspace, Input, [], None
# {1}, Test_Geodatabase, Test Geodatabase, Required, False, Workspace, Input, [], None
# {2}, Sort_Field, Sort Field, Required, False, String, Input, [], OBJECTID
# {3}, Compare_Type, Compare Type, Required, False, String, Input, [], None
# {4}, Output_File, Output File, Required, False, File, Output, [], None
# {5}, Ignore_Options, Ignore Options, Optional, True, String, Input, [], None
# {6}, Continue_Compare, Continue Compare, Optional, False, Boolean, Input, [], False
# {7}, Errors_Only, Errors Only, Optional, False, Boolean, Input, [], False
#-------------------------------------------------------------------------------

import arcpy, os, sys, time

THIS_FILE_NAME = "GeodatabaseCompare.py"


def trace():
    import traceback
    tb = sys.exc_info()[2]
    tbinfo = traceback.format_tb(tb)[0]
    line = tbinfo.split(", ")[1]
    filename = THIS_FILE_NAME
    synerror = traceback.format_exc().splitlines()[-1]
    return line, filename, synerror


# Returns a list of the full paths to every feature class contained in the workspace
def getFeatureClasses(workspace, featureClassList):
    arcpy.env.workspace = workspace

    # Append stand-alone feature class paths
    standAloneFeatureClasses = arcpy.ListFeatureClasses()

    for standAloneFeatureClass in standAloneFeatureClasses:
        featureClassList.append(os.path.join(workspace, standAloneFeatureClass))

    # Append feature dataset feature class paths
    featureDatasets = arcpy.ListDatasets("*", "Feature")

    for featureDataset in featureDatasets:
        featureDatasetPath = os.path.join(workspace, featureDataset)
        arcpy.env.workspace = featureDatasetPath
        featureClasses = arcpy.ListFeatureClasses()

        for featureClass in featureClasses:
            featureClassList.append(os.path.join(featureDatasetPath, featureClass))


# Returns a list of the full paths to every table (excluding feature classes) contained in the workspace
def getTables(workspace, tableList):
    arcpy.env.workspace = workspace
    tables = arcpy.ListTables()
    for table in tables:
        tableList.append(os.path.join(workspace, table))


# Returns the unqualified table name
def getUnqualifiedTableName(dataset):
    if len(dataset) > 0:
        index = dataset.rfind('.')
        sepIndex = dataset.rfind('\\')
        if index > -1 and index > sepIndex:
            index += 1
            return dataset[index:]
        elif sepIndex > -1:
            sepIndex += 1
            return dataset[sepIndex:]
    return dataset


# Creates a lookup of dataset paths by unqualified table name
def createDatasetLookup(datasetList, lookup):
    for dataset in datasetList:
        tableName = getUnqualifiedTableName(dataset.lower())
        lookup[tableName] = dataset


# Creates and initializes the consolidated report
def initializeReport(baseWorkspace, testWorkspace, outReportPath):
    # Create the output report header
    with open(outReportPath, 'w') as outFile:
        outFile.write("Data Comparison Report\n\n")
        outFile.write(time.strftime("%A, %B %d, %Y %H:%M:%S") + "\n\n")
        outFile.write("Compare results for:\n")
        outFile.write("BASE - %s\n" % baseWorkspace)
        outFile.write("TEST - %s\n\n" % testWorkspace)


# Appends one compare report to another with the option of only including errors
def appendReport(tempReport, outReport, errorsOnly):
    with open(outReport, 'a') as outFile:
        basename = os.path.basename(tempReport)
        i = basename.rfind('_')
        if i > -1:
            dataset = basename[:i].upper()
            with open(tempReport, 'r') as inFile:
                outFile.write("Summary for: %s\n" % dataset)
                if errorsOnly:
                    for line in inFile:
                        if line.find("\"false\"", 0, 7) == -1:
                            outFile.write(line)
                else:
                    for line in inFile:
                        outFile.write(line)


# Determines and returns the ArcCatalog metadata file path for the specified file path
def getMetadataFilePath(path):
    dirName = os.path.dirname(path)
    baseName = os.path.basename(path)
    baseNameNoExt = os.path.splitext(baseName)[0]
    return os.path.join(dirName, baseNameNoExt + ".xml")


# Remove the specified file and associated ArcCatalog metadata file
def removeTempFiles(tempReport):
    metadataFile = getMetadataFilePath(tempReport)

    if os.path.exists(tempReport):
        os.remove(tempReport)
    if os.path.exists(metadataFile):
        os.remove(metadataFile)


# Compares fields from the base dataset to fields from the test dataset
def compareFields(base, test, compareReport):
    # Compare editable fields
    baseFields = set([field.name.lower() for field in arcpy.ListFields(base) if field.editable])
    testFields = set([field.name.lower() for field in arcpy.ListFields(test) if field.editable])

    for baseField in baseFields:
        if baseField in testFields:
            # If field exists in base and test fields remove the field from the test field list.
            # The difference will be fields that exist in test but not in base.
            testFields.remove(baseField)
        else:
            # Field exists in base but not in test
            with open(compareReport, 'a') as f:
                f.write("\"true\", \"Field\", \"Field does not exist in Test Feature Class\", \"" + baseField + "\", \"\", -1\n")

    # If there are fields left in the test field list...
    if len(testFields) > 0:
        # Fields exist in test but not in base
        with open(compareReport, 'a') as f:
            for testField in testFields:
                f.write("\"true\", \"Field\", \"Field does not exist in Base Feature Class\", \"\", \"" + testField + "\", -1\n")


# Returns a semi-colon (';') delimited string of fields to omit from the comparison
def getOmitFields(base, test):
    # Omit fields that aren't editable
    baseOmitFields = set([field.name.lower() for field in arcpy.ListFields(base) if not field.editable])
    testOmitFields = set([field.name.lower() for field in arcpy.ListFields(test) if not field.editable])

    unionedOmitFields = baseOmitFields | testOmitFields

    notFirstElement = False

    for omitField in unionedOmitFields:
        if notFirstElement:
            omitFields = "%s;%s" % (omitFields, omitField)
        else:
            omitFields = omitField
            notFirstElement = True

    return omitFields


# Strips the spatial ignore options from the Ignore Options parameter value string
def stripSpatialIgnoreOptions(ignores):
    # Hard-coded ignore options for the TableCompare_management tool
    tableIgnoreSet = set(["IGNORE_EXTENSION_PROPERTIES", "IGNORE_SUBTYPES", "IGNORE_RELATIONSHIPCLASSES"])

    # Split the input parameter value
    ignoresSet = set(ignores.split(';'))

    # Intersect the two sets
    intersectionSet = tableIgnoreSet & ignoresSet

    # Re-construct the parameter value
    nonSpatialIgnores = ""
    notFirstElement = False

    for item in intersectionSet:
        if notFirstElement:
            nonSpatialIgnores = "%s;%s" % (nonSpatialIgnores, item)
        else:
            nonSpatialIgnores = item

    return nonSpatialIgnores


if __name__ == '__main__':

    arcpy.env.overwriteOutput = True

    # Parameters
    baseWorkspace = arcpy.GetParameterAsText(0)
    testWorkspace = arcpy.GetParameterAsText(1)
    sortField = arcpy.GetParameterAsText(2) # free text, default to OBJECTID
    compareType = arcpy.GetParameterAsText(3)
    outFile = arcpy.GetParameterAsText(4)
    ignoreOptions = arcpy.GetParameterAsText(5)
    continueCompare = arcpy.GetParameterAsText(6)
    errorsOnly = arcpy.GetParameter(7)

    outDir = os.path.dirname(outFile)

    try:
        # Create and initialize the output report
        initializeReport(baseWorkspace, testWorkspace, outFile)

        # Get feature classes
        baseFeatureClasses = []
        testFeatureClasses = []

        getFeatureClasses(baseWorkspace, baseFeatureClasses)
        getFeatureClasses(testWorkspace, testFeatureClasses)

        # Feature class lookups - full path by unqualified table name
        baseFeatureClassLookup = {}
        testFeatureClassLookup = {}

        createDatasetLookup(baseFeatureClasses, baseFeatureClassLookup)
        createDatasetLookup(testFeatureClasses, testFeatureClassLookup)

        # Loop through the base feature classes
        for baseFeatureClass in baseFeatureClasses:

            baseTableName = getUnqualifiedTableName(baseFeatureClass.lower())

            arcpy.AddMessage("Comparing %s feature class." % baseTableName.upper())

            # Temp compare report path
            curTime = time.strftime("%m%d%Y%H%M%S")
            tempFeatureClassComparePath = os.path.join(outDir, "%s_%s.txt" % (baseTableName, curTime))

            # If base table exists in the test workspace
            if testFeatureClassLookup.has_key(baseTableName):

                omitFields = ""
                testFeatureClass = testFeatureClassLookup[baseTableName]

                if compareType == "ALL" or compareType == "ATTRIBUTES_ONLY":
                    omitFields = getOmitFields(baseFeatureClass, testFeatureClass)

                # Execute FeatureCompare tool
                arcpy.FeatureCompare_management(baseFeatureClass, testFeatureClassLookup[baseTableName], sortField, compareType, ignoreOptions, "#", "#", "#", "#", omitFields, continueCompare, tempFeatureClassComparePath)

                # Add field comparison info
                if compareType == "ALL" or compareType == "SCHEMA_ONLY":
                    compareFields(baseFeatureClass, testFeatureClassLookup[baseTableName], tempFeatureClassComparePath)

            else:
                # Table exists in base but not in test
                with open(tempFeatureClassComparePath, 'w') as f:
                    f.write("Has_error, Identifier, Message, Base_value, Test_value, ObjectID\n")
                    f.write("\"true\", \"Table\", \"Table does not exist in Test database\", \"exists\", \"not exists\", -1\n")

            # Append the temp report to the consolidated output report and clean up temp files
            appendReport(tempFeatureClassComparePath, outFile, errorsOnly)
            removeTempFiles(tempFeatureClassComparePath)

        # At this point we have identified all of the feature classes that exist in both base and test.
        # Loop through test feature classes to identify tables that exist in test but not in base.
        for testFeatureClass in testFeatureClasses:
            testTableName = getUnqualifiedTableName(testFeatureClass.lower())

            if not baseFeatureClassLookup.has_key(testTableName):

                arcpy.AddMessage("Comparing %s feature class." % testTableName.upper())

                curTime = time.strftime("%m%d%Y%H%M%S")
                tempTestToBaseComparePath = os.path.join(outDir, "%s_%s.txt" % (testTableName, curTime))

                with open(tempTestToBaseComparePath, 'w') as f:
                    f.write("Has_error, Identifier, Message, Base_value, Test_value, ObjectID\n")
                    f.write("\"true\", \"Table\", \"Table does not exist in Base database\", \"not exists\", \"exists\", -1\n")

                # Append the temp report to the consolidated output report and clean up temp files
                appendReport(tempTestToBaseComparePath, outFile, errorsOnly)
                removeTempFiles(tempTestToBaseComparePath)

        # Only compare tables if a non-spatial compare type is chosen
        if compareType == "ALL" or compareType == "ATTRIBUTES_ONLY" or compareType == "SCHEMA_ONLY":
            # Get workspace tables
            baseTables = []
            testTables = []

            getTables(baseWorkspace, baseTables)
            getTables(testWorkspace, testTables)

            # Table lookups - full path by unqualified table name
            baseTableLookup = {}
            testTableLookup = {}

            createDatasetLookup(baseTables, baseTableLookup)
            createDatasetLookup(testTables, testTableLookup)

            # Loop through the base tables
            for baseTable in baseTables:
                baseTableName = getUnqualifiedTableName(baseTable.lower())

                arcpy.AddMessage("Comparing %s table." % baseTableName.upper())

                # Temp compare report path
                curTime = time.strftime("%m%d%Y%H%M%S")
                tempTableComparePath = os.path.join(outDir, "%s_%s.txt" % (baseTableName, curTime))

                # If base table exists in the test workspace
                if testTableLookup.has_key(baseTableName):

                    omitFields = ""
                    testTable = testTableLookup[baseTableName]

                    if compareType == "ALL" or compareType == "ATTRIBUTES_ONLY":
                        omitFields = getOmitFields(baseTable, testTable)

                    # Strip spatial ignore options
                    nonSpatialIgnores = stripSpatialIgnoreOptions(ignoreOptions)

                    # Execute TableCompare tool
                    arcpy.TableCompare_management(baseTable, testTableLookup[baseTableName], sortField, compareType, nonSpatialIgnores, "#", omitFields, continueCompare, tempTableComparePath)

                    # Add field comparison info
                    if compareType == "ALL" or compareType == "SCHEMA_ONLY":
                        compareFields(baseTable, testTableLookup[baseTableName], tempTableComparePath)

                    # Append the temp report to the consolidated output report and clean up temp files
                    appendReport(tempTableComparePath, outFile, errorsOnly)
                    removeTempFiles(tempTableComparePath)

            # Loop through the test tables
            for testTable in testTables:
                testTableName = getUnqualifiedTableName(testTable.lower())

                if not baseTableLookup.has_key(testTableName):

                    arcpy.AddMessage("Comparing %s table." % testTableName.upper())

                    curTime = time.strftime("%m%d%Y%H%M%S")
                    tempTestToBaseComparePath = os.path.join(outDir, "%s_%s.txt" % (testTableName, curTime))

                    with open(tempTestToBaseComparePath, 'w') as f:
                        f.write("Has_error, Identifier, Message, Base_value, Test_value, ObjectID\n")
                        f.write("\"true\", \"Table\", \"Table does not exist in Base database\", \"not exists\", \"exists\", -1\n")

                    # Append the temp report to the consolidated output report and clean up temp files
                    appendReport(tempTestToBaseComparePath, outFile, errorsOnly)
                    removeTempFiles(tempTestToBaseComparePath)

    except arcpy.ExecuteError:
        arcpy.AddError(arcpy.GetMessages(2))

    except Exception as e:
        line, filename, err = trace()
        arcpy.AddError("Geoprocessing error on " + line + " of " + filename + " :\n" + err)
