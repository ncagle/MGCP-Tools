# ----------------------------------------------------------------------------------------------------------------------
# COPYRIGHT 2017 ESRI
#
# TRADE SECRETS: ESRI PROPRIETARY AND CONFIDENTIAL
# Unpublished material - all rights reserved under the
# Copyright Laws of the United States.
#
# For additional information, contact:
# Environmental Systems Research Institute, Inc.
# Attn: Contracts Dept
# 380 New York Street
# Redlands, California, USA 92373
#
# email: contracts@esri.com
# ----------------------------------------------------------------------------------------------------------------------

# ----------------------------------------------------------------------------------------------------------------------
# Usage notes
# SuppressSpotHeights_defense(Input_Area_of_Interest,
# MTM50 | MTM100 | TM50 | TM100 | JOG_A,
# Data_Model_Version, Search_Distance, Input_Spot_Height_Features, SUPPRESS_FEATURES | DELETE_FEATURES)
#
# INDEX, NAME, DISPLAY NAME, PARAMETER TYPE, MULTIVALUE, DATA TYPE, DIRECTION, DEPENDENCIES, VALUE
# {0}, Input_Area_of_Interest, Input Area of Interest, Required, False, Feature Layer, Input, [], None
# {1}, Product_Type, Product Type, Required, False, String, Input, [], None
# {2}, Data_Model_Version, Data Model Version, Required, False, String, Input, [], None
# {3}, Search_Distance, Search Distance, Required, False, Linear unit, Input, [], 1300 Meters
# {4}, Input_Spot_Height_Features, Input Spot Height Features, Required, False, Feature Layer, Input, [], None
# {5}, Delete_Spot_Height_Features, Delete Spot Height Features, Required, False, Boolean, Input, [], False
# {6}, Output_Spot_Height_Features, Output Spot Height Features, Derived, False, Feature Layer, Output, [6], None
# ----------------------------------------------------------------------------------------------------------------------

import operator
from collections import defaultdict
from collections import OrderedDict

# Setting variable for file name
THIS_FILE_NAME = 'SuppressSpotHeights.py'


# Get the proper specification for the product and model
def setspecification(producttype, datamodel):
    from DefenseUtilities import GetSpecification
    specification = GetSpecification(producttype, datamodel)
    specification = specification.vstSpec
    specification = specification.split(':')
    specification = specification[0].strip()
    if producttype.startswith('TM') or producttype.startswith('ICM'):
        specification = 'HypsoP_{}'.format(specification)
    elif producttype.startswith('MTM'):
            specification = 'ElevP_{}'.format(specification)
    elif producttype.startswith('JOG'):
        if datamodel in ['VMap1JOGA']:
            specification = 'ElevP_Vmap1JOGA'
        elif datamodel in ['TDS_6_1', 'TDS_7']:
            specification = 'HypsoP_{}'.format(specification)
    return specification


# Check spots for specification
def checkspecification(spots, specification):
    from arcpy import ListFields
    fields = ListFields(spots)
    specfound = False
    for field in fields:
        if specification in field.baseName:
            specfound = True
            break
    if not specfound:
        raise Exception('Input spot height feature class does not have the required representation specification.')
    return


# Thin spots for each AOI feature selected. If no AOIs are selected, thin spots for all features.
def thinspots(aoi, spots, table, distance, specification, deleteSpots, inputContours):
    from arcpy import da, AddMessage, analysis, defense, management, mapping
    from DefenseUtilities import fieldexists
    lay = mapping.Layer(aoi)
    oIDs = lay.getSelectionSet()
    currentaoi = ''
    if oIDs == None:
        raise Exception('Input Area of Interest must have at least one feature selected.')
    for oID in oIDs:
        currentaoi = management.MakeFeatureLayer(aoi, 'currentAOI', "(OBJECTID = {})".format(str(oID)))
        selectedspots = management.MakeFeatureLayer(spots, 'selectedSpots')
        management.SelectLayerByLocation(selectedspots, 'WITHIN', currentaoi, '#', 'NEW_SELECTION')
        AddMessage('Calculating fields...')
        fieldzvh = fieldexists(selectedspots, u'ZVH')
        FieldZV2 = fieldexists(selectedspots, u'ZV2')
        fieldzv2 = fieldexists(selectedspots, u'zv2')
        hfield = ''
        if fieldzvh:
            hfield = 'ZVH'
        elif FieldZV2 or fieldzv2:
            if FieldZV2:
                hfield = 'ZV2'
            else:
                hfield = 'zv2'
        txtField = ''
        if fieldexists(selectedspots, u'ZI006_MEM'):
            txtField = 'ZI006_MEM'
        elif fieldexists(selectedspots, u'TXT'):
            txtField = 'TXT'
        elif fieldexists(selectedspots, u'txt'):
            txtField = 'txt'
        contourType = {}
        if inputContours:
            nearContourTable = arcpy.GenerateNearTable_analysis(selectedspots, inputContours, r'{}\nearContuorTable'.format(table), distance, '#', '#', 'CLOSEST')
            with da.SearchCursor(nearContourTable, ['IN_FID','NEAR_FID'])as cur1:
                for row1 in cur1:
                    with da.SearchCursor(inputContours, 'HQC', 'OBJECTID = {}'.format(str(row1[1]))) as cur2:
                        for row2 in cur2:
                            contourType[row1[0]] = row2[0]
                            break
                          
        if txtField != '':
            with da.UpdateCursor(selectedspots, [txtField, hfield], '{0} IS NOT NULL ORDER BY {0} DESC'.format(hfield)) as cur:
                row = cur.next()
                row[0] = 'Highest Point'
                cur.updateRow(row)
            
        spotTopPts = {}
        spotDepPts = {}
        with da.SearchCursor(selectedspots, ['OBJECTID', hfield], '{0} IS NOT NULL ORDER BY {0} DESC'.format(hfield)) as cur:
            for row in cur:
                if row[0] in contourType and (contourType[row[0]] == 5 or contourType[row[0]] == 6):
                    spotDepPts[row[0]] = row[1]
                else:
                    spotTopPts[row[0]] = row[1]
        orderedTopPts = OrderedDict(sorted(spotTopPts.items(), key=lambda x:x[1], reverse=True))
        orderedDepPts = OrderedDict(sorted(spotDepPts.items(), key=lambda x:x[1], reverse=False))
        
        neartable = analysis.PointDistance(selectedspots, selectedspots, r'{}\nearTable'.format(table), distance)        
        nearDict = defaultdict(list)
        with da.SearchCursor(neartable, ['INPUT_FID', 'NEAR_FID']) as cur:
            for row in cur:
                nearDict[row[0]].append(int(row[1]))
                
        spotsToDelete = []
        spotsToKeep = []
        lastKeptID = 0
        for fid in list(orderedTopPts.keys()):
            if fid in nearDict and fid not in spotsToDelete and fid in spotTopPts:
                spotsToKeep.append(fid)
                lastKeptID = fid
                for nearFid in nearDict[fid]:
                    if nearFid not in spotsToDelete and nearFid in spotTopPts:
                        spotsToDelete.append(nearFid)

        for fid in list(orderedDepPts.keys()):            
            if fid in nearDict and fid not in spotsToDelete  and fid in spotDepPts:
                spotsToKeep.append(fid)
                for nearFid in nearDict[fid]:
                    if nearFid not in spotsToDelete and nearFid in spotDepPts:
                        spotsToDelete.append(nearFid)
        
        if not inputContours and txtField != '':
            if spotTopPts[lastKeptID] == orderedTopPts.values()[-1] or lastKeptID == orderedTopPts.keys()[-1]:
                with da.UpdateCursor(selectedspots, [txtField, hfield, 'OBJECTID'], '{0} IS NOT NULL AND OBJECTID = {1} ORDER BY {0} ASC'.format(hfield, 'OBJECTID')) as cur:
                    row = cur.next()
                    row[0] = 'Lowest Point'
                    cur.updateRow(row)
            else:
                with da.UpdateCursor(selectedspots, [txtField, hfield, 'OBJECTID'], '{0} IS NOT NULL ORDER BY {0} ASC'.format(hfield)) as cur:
                    row = cur.next()
                    if row[2] in spotsToDelete:
                         spotsToDelete.remove(row[2])
                    
                    row[0] = 'Lowest Point'
                    cur.updateRow(row)
        elif inputContours and txtField != '':
            with da.UpdateCursor(selectedspots, [txtField, hfield], '{0} IS NOT NULL ORDER BY {0} ASC'.format(hfield)) as cur:
                row = cur.next()
                row[0] = 'Lowest Point'
                cur.updateRow(row)
                
                
        query = ','.join(map(str, spotsToDelete))
        if query != '':      
            if query[len(query) - 1] == ',':
                query = query[:-1]
            #management.SelectLayerByAttribute(selectedspots, 'REMOVE_FROM_SELECTION', 'OBJECTID IN ({})'.format(query))
            management.SelectLayerByAttribute(selectedspots, 'NEW_SELECTION', 'OBJECTID IN ({})'.format(query))
            if deleteSpots == 'true':
                management.DeleteFeatures(selectedspots)
            else:
                defense.MakeRepsInvisible(selectedspots, specification)
                
    return currentaoi, selectedspots, table


# Delete temp layers
def deletetemp(aoi, selectedspots, table):
    from arcpy import management, AddWarning
    try:
        management.Delete(r'{}\nearTable'.format(table))
        management.Delete(selectedspots)
        management.Delete(aoi)
    except Exception as e:
        AddWarning(e)


# Main execution
def main():
    from arcpy import GetParameterAsText, SetParameter, AddWarning
    from DefenseUtilities import checkoutextensions, setenvironment
    
    try:
        checkoutextensions(['defense'])
        table, folder, templist = setenvironment()
        specification = setspecification(GetParameterAsText(1), GetParameterAsText(2))
        checkspecification(GetParameterAsText(4), specification)
        inputContours = GetParameterAsText(7)
        currentaoi, selectedspots, table = thinspots(GetParameterAsText(0), GetParameterAsText(4), table,
                                                     GetParameterAsText(3), specification, GetParameterAsText(5), inputContours)
        SetParameter(6, GetParameterAsText(4))
        deletetemp(currentaoi, selectedspots, table)
    except Exception as e:
        from arcpy import AddError
        from DefenseUtilities import trace
        line, filename, err = trace(THIS_FILE_NAME)
        AddError('Geoprocessing error on {} of {} :\n{}'.format(line, filename, err, e))
    finally:
        from os import path
        from shutil import rmtree
        try:
            folder = path.split(table)[0]
            rmtree(folder, True)
        except Exception as e:
            AddWarning(e)

# Run main
if __name__ == '__main__':
    main()
