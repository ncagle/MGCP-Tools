# ------------------------------------------------------------------------------------------------
# COPYRIGHT 2017 ESRI
#
# TRADE SECRETS: ESRI PROPRIETARY AND CONFIDENTIAL
# Unpublished material - all rights reserved under the
# Copyright Laws of the United States.
#
# For additional information, contact:
# Environmental Systems Research Institute, Inc.
# Attn: Contracts Dept
# 380 New York Street
# Redlands, California, USA 92373
#
# email: contracts@esri.com
# ------------------------------------------------------------------------------------------------

# ------------------------------------------------------------------------------------------------
# Usage notes
# CalculateVerticalObstructionElevations_defense(Input_Geodatabase, Geodatabase_Type, Input_DEM)
# INDEX, NAME, DISPLAY NAME, PARAMETER TYPE, MULTIVALUE, DATA TYPE, DIRECTION, DEPENDENCIES, VALUE
# {0}, Input_Geodatabase, Input Geodatabase, Required, False, Workspace, Input, [], None
# {1}, Geodatabase_Type, Geodatabase Type, Required, False, String, Input, [], MGCP
# {2}, Input_DEM, Input DEM, Required, False, Raster Layer, Input, [], None
# ------------------------------------------------------------------------------------------------

'''

Tool Name: Calculate Vertical Obstruction Elevations
Source Name: CalculateVerticalObstructionElevations.py
Version: 10.4.1
Author: ESRI

Searches an input geodatabase for pre-designated vertical obstruction feature classes, adding and
calculating elevation data from an input digital elevation model (DEM) raster layer if necessary.

'''

import arcpy, os
from DefenseUtilities import trace

''' The following is the configuration of vertical obstruction feature classes by type. Add or
    remove types and/or feature classes as needed.  All entries should be upper-case.  '''
fcsByType = {
    'MGCP': {'AGRISTRA': [True, "", 'HGT'],
             'AGRISTRP': [True, "", 'HGT'],
             'AQUEDCTA': [True, "", 'HGT'],
             'AQUEDCTL': [True, "", 'HGT'],
             'BARRIERL': [True, "", 'HGT'],
             'BRIDGEL': [True, "", 'OHB'],
             'BUILDA': [True, "", 'HGT'],
             'BUILDP': [True, "", 'HGT'],
             'COMMP': [True, "", 'HGT'],
             'DAMA': [True, "", 'HGT'],
             'DAML': [True, "", 'HGT'],
             'DAMP': [True, "", 'HGT'],
             'DANGERP': [True, "", 'HGT'],
             'DISPOSEA': [True, "", 'HGT'],
             'EMBANKA': [True, "", 'HGT'],
             'EMBANKL': [True, "", 'HGT'],
             'FORTA': [True, "", 'HGT'],
             'FORTP': [True, "", 'HGT'],
             'INDL': [True, "", 'HGT'],
             'LOCKL': [True, "", 'HGT'],
             'LANDMRKA': [True, "", 'HGT'],
             'LANDMRKL': [True, "", 'HGT'],
             'LANDMRKP': [True, "", 'HGT'],
             'MISCAEROP': [True, "", 'HGT'],
             'MISCL': [True, "", 'HGT'],
             'MISCP': [True, "", 'HGT'],
             'MTNP': [False, "F_CODE = 'DB150'", 'HGT'],
             'OBSTRP': [True, "", 'HGT'],
             'PIPEL': [True, "", 'HGT'],
             'POWERL': [True, "", 'HGT'],
             'RIGWELLP': [True, "", 'HGT'],
             'RUNWAYL': [True, "", 'HGT'],
             'STORAGEA': [True, "", 'HGT'],
             'STORAGEP': [True, "", 'HGT'],
             'TELEL': [True, "", 'HGT'],
             'TOWERP': [True, "", 'HGT'],
             'UTILP': [True, "", 'HGT']},
    'TDS': {'STRUCTUREPNT': [True, "", 'HGT'],
           'STRUCTURECRV': [True, "", 'HGT'],
           'STRUCTURESRF': [True, "", 'HGT'],
           'TRANSPORTATIONGROUNDCRV': [True, "", 'HGT'],
           'TRANSPORTATIONGROUNDSRF': [True, "", 'HGT'],
           'TRANSPORTATIONGROUNDPNT': [True, "", 'HGT'],
           'RECREATIONSRF': [True, "", 'HGT'],
           'RECREATIONCRV': [True, "", 'HGT'],
           'RECREATIONPNT': [True, "", 'HGT'],
           'INDUSTRYSRF': [True, "", 'HGT'],
           'INDUSTRYPNT': [True, "", 'HGT'],
           'UTILITYINFRASTRUCTUREPNT': [True, "", 'HGT'],
           'AERONAUTICPNT': [True, "", 'HGT']}
    }


# These are the configured elevation and height field names
ELEV_FIELD = 'ZVH'


def main():
    ''' This is the main point of entry for the script. '''

    # Input geodatabase
    inGdb = arcpy.GetParameterAsText(0)
    # Input geodatabase or product type
    gdbType = arcpy.GetParameterAsText(1).upper()
    # Input DEM raster layer
    inDem = arcpy.GetParameter(2)

    if not gdbType in fcsByType:
        arcpy.AddError('Geodatabase type not supported.')
        return

    rasterLayer = 'rasterLayer'

    try:
        # Get the vertical obstruction feature class names
        fcsToUpdate = fcsByType[gdbType]

        arcpy.MakeRasterLayer_management(inDem, rasterLayer)

        sr = arcpy.SpatialReference(4326)
        rasterDesc = arcpy.Describe(rasterLayer)
        if not rasterDesc is None and hasattr(rasterDesc, 'spatialReference'):
            sr = rasterDesc.spatialReference
        del rasterDesc

        fcsInGdb = []
        walk = arcpy.da.Walk(inGdb, datatype='FeatureClass')

        for path, dirnames, featureClassNames in walk:
            for featureClassName in featureClassNames:
                fcsInGdb.append(os.path.join(path, featureClassName))

        for fc in fcsInGdb:
            fcBasename = unqualifyName(os.path.basename(fc)).upper()

            if fcBasename in fcsToUpdate:
                arcpy.AddMessage('Found {0}...'.format(fcBasename))

                # Add fields if they don't exist; field type = long integer
                addField(fc, fcsToUpdate[fcBasename][2], 'LONG')
                elevFieldAdded = addField(fc, ELEV_FIELD, 'LONG')
                calculateElevations(inGdb, fc, rasterLayer, sr, fcsToUpdate[fcBasename][0], fcsToUpdate[fcBasename][1], fcsToUpdate[fcBasename][2])
        arcpy.SetParameter(3, inGdb)
    except arcpy.ExecuteError:
        arcpy.AddError(arcpy.GetMessages(2))
    except Exception as ex:
        line, f, e = trace('CalculateVerticalObstructionElevations.py')
        errmsg = 'Exception in {0} line {1}:\n\t{2}'.format(f, line, e)
        arcpy.AddError(errmsg)
    finally:
        if arcpy.Exists(rasterLayer):
            arcpy.Delete_management(rasterLayer)


def calculateElevations(gdb, fc, demLayer, sr, requireHgt, query, hgtfield):
    ''' Calculates elevations on input features using an input raster layer (DEM).  The true centroid
        is used on polyline and polygon features.

        Parameters:
            gdb (string): path to the edit workspace.
            fc (string): path to the input feature class.
            demLayer (raster layer): input raster layer.
            sr (spatial reference): spatial reference to use for input features.
            requireHgt (boolean): determine how elevation is calculated. True means that elevation is only calculated if
                                  the height field has a valid value and is calculated as the sum of the base elevation
                                  and the height field. False means that the base elevation alone will be used to
                                  calculate the elevation field.
            query (string): sql query to limit elevation calculation to a subset of features
    '''

    # Get the count and abort if there are no features to calculate
    count = int(arcpy.GetCount_management(fc).getOutput(0))
    if count < 1:
        return

    # edit = None
    arcpy.AddMessage('-- Calculating elevations [{}]'.format(ELEV_FIELD))

    # Get X,Y for point features; true centroid X,Y for other shape types
    shapeField = 'SHAPE@XY'
    fcDesc = arcpy.Describe(fc)
    if fcDesc.shapeType != 'Point':
        shapeField = 'SHAPE@TRUECENTROID'
    del fcDesc

    arcpy.SetProgressor('step', 'Calculating {}...'.format(ELEV_FIELD), 0, count, 1)

    try:
        with arcpy.da.Editor(gdb) as edit:
            with arcpy.da.UpdateCursor(fc, [ELEV_FIELD, hgtfield, shapeField], query, sr) as cursor:
                for row in cursor:
                    if row[0] == None or row[0] == -32768 or row[0] == -32767 or row[0] == -999999:
                        arcpy.SetProgressorPosition()
                        coord = row[2]
                        # GetCellValue outputs the cell value of the specified coordinate; if the coordinate
                        # falls outside of the raster layer or if the intersected cell has no value a value
                        # 'NoData' is returned.
                        result = arcpy.GetCellValue_management(demLayer, '{0} {1}'.format(coord[0], coord[1]))
                        resultVal = result.getOutput(0)
                        if resultVal != 'NoData':
                            elev = int(resultVal)
                            if requireHgt:
                                if row[1] == -32768 or row[1] == -32767 or row[1] == -999999 or row[1] is None:
                                    continue
                                else:
                                    row[0] = elev + row[1]
                            else:
                                row[0] = elev
                            cursor.updateRow(row)
    except:
        raise
    finally:
        arcpy.ResetProgressor()


def addField(fc, fieldname, fieldtype):
    ''' Adds a field to a feature class or table.

        Parameters:
            fc (string): path to the feature class or table.
            fieldname (string): the name of the field to add.
            fieldtype (string): the field type.

        Returns:
            True if the field is added; otherwise False.
    '''

    # Don't add if the field already exists
    if fieldExists(fc, fieldname):
        arcpy.AddMessage('-- {0} field exists.'.format(fieldname))
        return False
    try:
        arcpy.AddMessage('-- Adding {0} field.'.format(fieldname))
        arcpy.AddField_management(fc, fieldname, fieldtype)
        return True
    except arcpy.ExecuteError:
        arcpy.AddWarning('-- Failed to add {0} field.'.format(fieldname))
        arcpy.AddWarning('    {}'.format(arcpy.GetMessages(2)))
    return False


def unqualifyName(name):
    ''' Unqualifies a table name.

        Parameters:
            name (string): the table name.

        Returns:
            The base unqualified table name.
    '''
    if name is None or len(name) < 1:
        return name
    return name[name.rfind('.')+1:]


def fieldExists(fc, fieldname):
    ''' Indicates whether a field exists on a given feature class or table.

        Parameters:
            fc (string): path to the input feature class or table.
            fieldname (string): the field name.

        Returns:
            True if the field exists; otherwise False.
    '''
    try:
        if not arcpy.Exists(fc):
            return False
        # Case-insensitive
        fieldnames = [field.name.upper() for field in arcpy.ListFields(fc)]
        return fieldname.upper() in fieldnames
    except:
        return False

if __name__ == '__main__':
    main()
