#-*- coding:utf8 -*-
#
# Description: Change Schema Ownership Of User in SQL Database
# ---------------------------------------------------------------------------

# This script will only work on Microsoft SQL Server.
# For the Login defined in the connnection file, it will create/alter a database user account
# to match the name of the specified schema and set it's default schema to the specified schema.
# It performs error checking to ensure no other user is currently logged in and assuming ownership
# of the specified schema.
# NOTES:
# 		1. Using dynamic SQL (sp_executesql) because variables are not allowed in TSQL statments.
# 		2. Did not use EXEC([statement]) because when SET FMTONLY ON is used it causes errors (SDE uses SET FMTONLY)
#  		3. ALTER USER WITH LOGIN may not be supported on some SQL Server versions when executed in dynamic SQL
#		4. PRINT statments in CATCH block prevent error from being returned to ArcMap
#		5. The following permissions are required for the Login executing the script:
# 			ALTER ANY USER
# 			CONTROL Database (for remapping user to login)
# 			VIEW SERVER STATE (for access to all processes in sys.sysprocesses)
# 			ALTER ANY LOGIN (for access to all sys.server_principals)
#		6. With SQL Server 2012 and greater SDE executes sp_describe_first_result_set for each prepared sql statement.
#			This stored procedure fails if the statement is executing dynamic sql.  If the SQL Server
#			version is >= 2012 execute dynamic sql statements using WITH RESULT SETS NONE

import arcpy
import re
import sys

#Parameters
SDEConnection = sys.argv[1]
Schema = sys.argv[2]

DynamicSQLWithResultSet = "EXEC sp_executesql @SQL WITH RESULT SETS NONE"
DynamicSQLWithoutResultSet = "EXEC sp_executesql @SQL"

SQLVersionStmt = "\r\n\
DECLARE @VERSTRING NVARCHAR(128) \r\n\
DECLARE @VERNUM INT \r\n\
SET @VERSTRING = CAST(SERVERPROPERTY('ProductVersion') AS NVARCHAR) \r\n\
SET @VERSTRING = SUBSTRING(@VERSTRING, 1, CHARINDEX('.', @VERSTRING) - 1) \r\n\
SET @VERNUM = CAST(@VERSTRING AS INT) \r\n\
\r\n\
SELECT @VERNUM"

SQLStmt = "\r\n\
DECLARE @ERRMSG NVARCHAR(4000) \r\n\
DECLARE @SEVERITY int \r\n\
DECLARE @STATE int \r\n\
DECLARE @ERRORLINE int \r\n\
DECLARE @SCHEMA NVARCHAR(255) \r\n\
DECLARE @SQL NVARCHAR(4000) \r\n\
DECLARE @USER_SID VARBINARY(85) \r\n\
SET @USER_SID = SUSER_SID() \r\n\
SET @SCHEMA = \'" + Schema + "\' \r\n\
\r\n\
IF NOT EXISTS(SELECT 1 FROM SYS.SCHEMAS WHERE NAME = @SCHEMA) \r\n\
BEGIN \r\n\
	SET @ERRMSG = 'Schema ' + @SCHEMA + ' does not exist.' \r\n\
	RAISERROR(@ERRMSG,11,1) \r\n\
	RETURN \r\n\
END \r\n\
\r\n\
DECLARE @LOGIN_NAME NVARCHAR(255) \r\n\
DECLARE @USER_NAME NVARCHAR(255) \r\n\
\r\n\
SELECT @LOGIN_NAME = sp.name, @USER_NAME = dp.name \r\n\
FROM sys.server_principals sp \r\n\
LEFT JOIN sys.database_principals dp ON sp.sid = dp.sid \r\n\
WHERE sp.sid = @USER_SID \r\n\
\r\n\
IF EXISTS (SELECT 1 \r\n\
	FROM sys.sysprocesses p \r\n\
	JOIN sys.server_principals sp ON p.sid = sp.sid \r\n\
	JOIN sys.database_principals dp ON sp.sid = dp.sid \r\n\
	WHERE p.sid <> @USER_SID and p.dbid = DB_ID() \r\n\
	AND dp.name = @SCHEMA) \r\n\
BEGIN \r\n\
	DECLARE @OTHER_USER NVARCHAR(255) \r\n\
	SELECT @OTHER_USER = p.loginame \r\n\
	FROM sys.sysprocesses p \r\n\
	JOIN sys.server_principals sp ON p.sid = sp.sid \r\n\
	JOIN sys.database_principals dp ON sp.sid = dp.sid \r\n\
	WHERE p.sid <> @USER_SID and p.dbid = DB_ID() \r\n\
	AND dp.name = @SCHEMA \r\n\
	SET @ERRMSG = 'Another user currently has ownership of the schema, user: ' + @OTHER_USER \r\n\
	RAISERROR(@ERRMSG,11,1) \r\n\
	RETURN \r\n\
END \r\n\
\r\n\
IF @LOGIN_NAME IS NULL \r\n\
BEGIN \r\n\
	BEGIN TRY \r\n\
		SET @SQL = 'CREATE LOGIN [' + SUSER_SNAME(@USER_SID) + '] FROM WINDOWS WITH DEFAULT_DATABASE=[master]' \r\n\
		[DYNAMIC_SQL] \r\n\
		SELECT @LOGIN_NAME = sp.name \r\n\
		FROM sys.server_principals sp \r\n\
		LEFT JOIN sys.database_principals dp ON sp.sid = dp.sid \r\n\
		WHERE sp.sid = @USER_SID \r\n\
	END TRY \r\n\
	BEGIN CATCH \r\n\
		SET @ERRMSG = 'No Login exists for this principal.  Attempted to create Login but failed with error: ' + ERROR_MESSAGE() \r\n\
		SET @SEVERITY = ERROR_SEVERITY() \r\n\
		SET @STATE = ERROR_STATE() \r\n\
		SET @ERRORLINE = ERROR_LINE() \r\n\
		RAISERROR (@ERRMSG, @SEVERITY, @STATE) \r\n\
		RETURN \r\n\
	END CATCH \r\n\
END \r\n\
\r\n\
IF @USER_NAME IS NULL \r\n\
BEGIN \r\n\
	BEGIN TRY \r\n\
		SET @SQL = 'CREATE USER [' + @LOGIN_NAME + '] FOR LOGIN [' + @LOGIN_NAME + '] WITH DEFAULT_SCHEMA = [' + @LOGIN_NAME + ']' \r\n\
		[DYNAMIC_SQL] \r\n\
		SELECT @USER_NAME = dp.name \r\n\
		FROM sys.server_principals sp \r\n\
		LEFT JOIN sys.database_principals dp ON sp.sid = dp.sid \r\n\
		WHERE sp.sid = @USER_SID \r\n\
	END TRY \r\n\
	BEGIN CATCH \r\n\
		SET @ERRMSG = 'No User exists for Login ' + @LOGIN_NAME + '.  Attempted to create User but failed with error: ' + ERROR_MESSAGE() \r\n\
		SET @SEVERITY = ERROR_SEVERITY() \r\n\
		SET @STATE = ERROR_STATE() \r\n\
		SET @ERRORLINE = ERROR_LINE() \r\n\
		RAISERROR (@ERRMSG, @SEVERITY, @STATE) \r\n\
		RETURN \r\n\
	END CATCH \r\n\
END \r\n\
\r\n\
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = @LOGIN_NAME) \r\n\
BEGIN \r\n\
	SET @SQL = 'CREATE SCHEMA [' + @LOGIN_NAME + ']' \r\n\
	[DYNAMIC_SQL] \r\n\
END \r\n\
\r\n\
DECLARE @PREVIOUS_OWNER NVARCHAR(255) \r\n\
\r\n\
BEGIN TRY \r\n\
	SELECT @PREVIOUS_OWNER = sp.name \r\n\
	FROM sys.server_principals sp \r\n\
	LEFT JOIN sys.database_principals dp ON sp.sid = dp.sid \r\n\
	WHERE dp.name = @SCHEMA \r\n\
\r\n\
	IF @PREVIOUS_OWNER IS NOT NULL AND @LOGIN_NAME <> @PREVIOUS_OWNER \r\n\
	BEGIN \r\n\
		IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = @PREVIOUS_OWNER) \r\n\
		BEGIN \r\n\
			SET @SQL = 'CREATE SCHEMA [' + @PREVIOUS_OWNER + ']' \r\n\
			[DYNAMIC_SQL] \r\n\
		END \r\n\
\r\n\
		IF EXISTS(SELECT 1 FROM sys.database_principals WHERE name = @PREVIOUS_OWNER) \r\n\
		BEGIN \r\n\
			SET @SQL = 'ALTER USER [' + @PREVIOUS_OWNER + '] WITH LOGIN = [' + @PREVIOUS_OWNER + '], DEFAULT_SCHEMA = [' + @PREVIOUS_OWNER + ']' \r\n\
			[DYNAMIC_SQL] \r\n\
		END \r\n\
		ELSE \r\n\
		BEGIN \r\n\
			SET @SQL = 'ALTER USER [' + @SCHEMA + '] WITH NAME = [' + @PREVIOUS_OWNER + '], DEFAULT_SCHEMA = [' + @PREVIOUS_OWNER + ']' \r\n\
			[DYNAMIC_SQL] \r\n\
		END \r\n\
	END \r\n\
\r\n\
	IF @USER_NAME <> @SCHEMA \r\n\
	BEGIN \r\n\
		IF EXISTS(SELECT 1 FROM sys.database_principals WHERE name = @SCHEMA) \r\n\
		BEGIN \r\n\
			SET @ERRMSG = 'User ' + @SCHEMA + ' already exists and Login ' + @LOGIN_NAME + ' cannot be remapped from ' + @USER_NAME + ' to existing user ' + @SCHEMA \r\n\
			RAISERROR(@ERRMSG,11,1) \r\n\
			RETURN \r\n\
		END \r\n\
		ELSE \r\n\
		BEGIN \r\n\
			SET @SQL = 'ALTER USER [' + @USER_NAME + '] WITH NAME = [' + @SCHEMA + '], DEFAULT_SCHEMA = [' + @SCHEMA + ']' \r\n\
			[DYNAMIC_SQL] \r\n\
		END \r\n\
	END \r\n\
	ELSE \r\n\
	BEGIN \r\n\
		DECLARE @DEFAULT_SCHEMA sysname \r\n\
		SELECT @DEFAULT_SCHEMA = dp.default_schema_name \r\n\
		FROM sys.server_principals sp \r\n\
		LEFT JOIN sys.database_principals dp ON sp.sid = dp.sid \r\n\
		WHERE sp.sid = SUSER_SID() \r\n\
		IF @SCHEMA <> @DEFAULT_SCHEMA \r\n\
		BEGIN \r\n\
			SET @SQL = 'ALTER USER [' + @USER_NAME + '] WITH DEFAULT_SCHEMA = [' + @SCHEMA + ']' \r\n\
			[DYNAMIC_SQL] \r\n\
		END \r\n\
	END \r\n\
END TRY \r\n\
BEGIN CATCH \r\n\
SET @ERRMSG = ERROR_MESSAGE() \r\n\
SET @SEVERITY = ERROR_SEVERITY() \r\n\
SET @STATE = ERROR_STATE() \r\n\
SET @ERRORLINE = ERROR_LINE() \r\n\
\r\n\
RAISERROR (@ERRMSG, @SEVERITY, @STATE) \r\n\
RETURN \r\n\
END CATCH \r\n"

try:
        #Connection to database
        sdeConn = arcpy.ArcSDESQLExecute(SDEConnection)
		#Get version of SQL Server
        SQLServerVersion = sdeConn.execute(SQLVersionStmt.encode('utf-8'))
        #If version is 2012 or greater use dynamic sql with result sets none
        if SQLServerVersion >= 11:
                SQLStmt = re.sub("\[DYNAMIC_SQL\]", DynamicSQLWithResultSet, SQLStmt)
        else:
                SQLStmt = re.sub("\[DYNAMIC_SQL\]", DynamicSQLWithoutResultSet, SQLStmt)

        sdeReturn = sdeConn.execute(SQLStmt.encode('utf-8'))
except Exception, ErrorDesc:
	error = str(ErrorDesc.args)
	sys.stderr.write(error)
	sdeReturn = False

#Check its status.
if sdeReturn == True:
	sys.stdout.write('Success')
else:
	sys.stdout.write('Fail')
