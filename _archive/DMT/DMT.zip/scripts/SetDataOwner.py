import arcpy
import re
import subprocess
import _winreg
import sys
import os

#Parameters
SDEConnection = arcpy.GetParameterAsText(0)
Schema = arcpy.GetParameterAsText(1)

def get_reg_value(hkey, subkey, name):
	aKey = _winreg.OpenKey(hkey, subkey)
	return _winreg.QueryValueEx(aKey, name)[0]
	
def get_defense_path():
	version = get_version()
	subkeys = [
	r"SOFTWARE\Wow6432Node\EsriProduction\Desktop" + version + "\ESRIDefenseMapping",
	r"SOFTWARE\EsriProduction\Desktop" + version + "\ESRIDefenseMapping",
	r"SOFTWARE\EsriProduction\Server" + version + "\ESRIDefenseMapping"
	]
	
	value = None
	for key in subkeys:
		try:
			value = get_reg_value(_winreg.HKEY_LOCAL_MACHINE, key, "InstallDir")
			break
		except Exception as e:
			continue
	
	if value is None:
		raise Exception("Unable to get registry value for Defense Mapping directory.")

	path = os.path.join(value, "ArcToolbox", "Scripts", "")
	if not os.path.exists(path):
		raise Exception('Unable to get registry value for Defense Mapping directory. Invalid path: ' + path)
	return path

def get_version():
	subkeys = [
	r"SOFTWARE\Wow6432Node\ESRI\ArcGIS",
	r"SOFTWARE\ESRI\ArcGIS"
	]
	
	value = None
	for key in subkeys:
		try:
			value = get_reg_value(_winreg.HKEY_LOCAL_MACHINE, key, "RealVersion")
			break
		except Exception as e:
			continue
	
	if value is None:
		raise Exception('Unable to get registry value for ArcGIS version.')
		
	index = value.find(".", value.find(".") + 1)
	return value[:index]
		
def get_python_path():
	version = get_version()
	subkeys = [
	r"SOFTWARE\Wow6432Node\ESRI\Python" + version,
	r"SOFTWARE\ESRI\Python" + version
	]
	
	value = None
	for key in subkeys:
		try:
			value = get_reg_value(_winreg.HKEY_LOCAL_MACHINE, key, "PythonDir")
			break
		except Exception as e:
			continue
		
	if value is None:
		raise Exception('Unable to get registry value for Python directory.')
		
	arcgis = "ArcGIS" + version
	path = os.path.join(value, arcgis, "python.exe")
	if not os.path.exists(path):
		arcgis = "ArcGISx64" + version
		path = os.path.join(value, arcgis, "python.exe")
	if not os.path.exists(path):
		raise Exception("Invalid Path: " + path)
	return path
	

python_path = get_python_path()
defense_script = os.path.join(get_defense_path(), "SetDataOwner_Subprocess.py")

paramlist = [python_path, defense_script, SDEConnection, Schema]
proc = None
stddata = None

try:
	proc = subprocess.Popen(paramlist,bufsize=0,shell=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
	stddata = proc.communicate()
except Exception as e:
	arcpy.AddError(str(e))
	arcpy.SetParameterAsText(2,"False")
	sys.exit(1)
	
if len(stddata) > 0:	
	if str(stddata[0]).lower() == "fail":
		arcpy.SetParameterAsText(2,"False")
		if len(stddata) > 1:
			arcpy.AddError("Failed to change data owner: " + str(stddata[1]))
		else:
			arcpy.AddError("Failed to change data owner")
	elif str(stddata[0]).lower() == "success":
		arcpy.SetParameterAsText(2,"True")
	else:
		arcpy.SetParameterAsText(2,"False")
		if len(stddata) > 1 and stddata[1] != "None":
			arcpy.AddError("Failed to change data owner. " + str(stddata[1]))
		else:
			arcpy.AddError("Failed to change data owner")
else:
	arcpy.SetParameterAsText(2,"False")
	arcpy.AddError("Failed to change data owner")