# COPYRIGHT 2017 ESRI
#
# TRADE SECRETS: ESRI PROPRIETARY AND CONFIDENTIAL
# Unpublished material - all rights reserved under the
# Copyright Laws of the United States.
#
# For additional information, contact:
# Environmental Systems Research Institute, Inc.
# Attn: Contracts Dept
# 380 New York Street
# Redlands, California, USA 92373
#
# email: contracts@esri.com

# ----------------------------------------------------------------------------------------------------------------------
# Usage notes
# BuildingOffsets_defense(Product_File, Dataset, Coordinate_System)
#
# INDEX, NAME, DISPLAY NAME, PARAMETER TYPE, MULTIVALUE, DATA TYPE, DIRECTION, DEPENDENCIES, VALUE
# {0}, Product_File, Product File, Required, False, File, Input, [], None
# {1}, Dataset, Dataset, Required, False, [u'Workspace', u'Feature Dataset'], Input, [], None
# {2}, Coordinate_System, Coordinate System, Required, False, Coordinate System, Input, [], None
# {3}, Selected_Features, Selected Features, Derived, True, Feature Layer, Output, [], None
# ----------------------------------------------------------------------------------------------------------------------

import arcpy
import xml.etree.ElementTree as Tree


# High Level Functions
def executealignmarkers(datasets, settings):
    settings_group = settings.findall('AlignMarkerToStrokeOrFill')
    for setting in settings_group:
        try:
            marker_rep = 'markerRep'
            stroke_rep = 'strokeRep'
            marker_element = getelement(setting, 'MarkerRepresenations')
            stroke_element = getelement(setting, 'StrokeOrFillRepresentations')
            for dataset in datasets:
                if arcpy.Exists(fileunion(dataset, gettext(marker_element))):
                    marker = fileunion(dataset, gettext(marker_element))
                if arcpy.Exists(fileunion(dataset, gettext(stroke_element))):
                    stroke = fileunion(dataset, gettext(stroke_element))
            createlayerwithreps(marker, marker_rep, getattribute(marker_element, 'query'),
                                getattribute(marker_element, 'reps'))
            createlayerwithreps(stroke, stroke_rep, getattribute(stroke_element, 'query'),
                                getattribute(stroke_element, 'reps'))
            search_distance = getdistance(getelement(setting, 'SearchDistance'))
            marker_orientation = gettext(getelement(setting, 'MarkerOrientation'))
            arcpy.cartography.AlignMarkerToStrokeOrFill(marker_rep, stroke_rep, search_distance, marker_orientation)
            delete(marker_rep)
            delete(stroke_rep)
        except Exception as e:
            arcpy.AddWarning(e)


def executecalculatehierarchies(datasets, settings):
    setting = getelement(settings, 'Hierarchies')
    field = getattribute(setting, 'field')
    for hierarchy in setting.findall('Hierarchy'):
        try:
            feature_class = gettext(hierarchy)
            layer = 'hierarchy'
            for dataset in datasets:
                if arcpy.Exists(fileunion(dataset, feature_class)):
                    createlayer(fileunion(dataset, feature_class), layer, getattribute(hierarchy, 'query'))
            addhierarchyfield(layer, field)
            arcpy.management.CalculateField(layer, field, getattribute(hierarchy, 'value'), 'PYTHON', '#')
            delete(layer)
        except Exception as e:
            arcpy.AddWarning(e)


def executeresolvebuildingconflicts(datasets, settings):
    setting = getelement(settings, 'ResolveBuildingConflicts')
    hierarchy = gettext(getelement(setting, 'HierarchyField'))
    invisibility = gettext(getelement(setting, 'InvisibilityField'))
    building_layers = createbuildingslayers(datasets, getelement(setting, 'Buildings'), invisibility)
    barrier_layers = createbarrierlayers(datasets, getelement(setting, 'Barriers'))
    buildings = makebuildingstring(building_layers)
    barriers = makebarrierstring(barrier_layers)
    gap = getdistance(getelement(setting, 'BuildingGap'))
    min_size = getdistance(getelement(setting, 'MinimumAllowableBuildingSize'))
    try:
        arcpy.cartography.ResolveBuildingConflicts(buildings, invisibility, barriers, gap, min_size, hierarchy)
    except Exception as e:
        arcpy.AddWarning(e)
    selectinvisiblefeatures(building_layers, invisibility)
    deletebarrierlayers(barrier_layers)
    return buildings


# Support Functions
def addhierarchyfield(featureclass, field):
    try:
        if not fieldexists(featureclass, field):
            arcpy.management.AddField(featureclass, field, 'LONG', '#', '#', '#', '#', 'NULLABLE', 'NON_REQUIRED', '#')
    except Exception as e:
        arcpy.AddWarning(e)


def addfieldvisibilityfield(featureclass, field):
    try:
        if not fieldexists(featureclass, field):
            arcpy.management.AddField(featureclass, field, 'SHORT', '#', '#', '#', '#', 'NULLABLE', 'NON_REQUIRED', '#')
    except Exception as e:
        arcpy.AddWarning(e)


def selectinvisiblefeatures(buildinglayers, field):
    for building in buildinglayers:
        try:
            arcpy.management.SelectLayerByAttribute(building, 'NEW_SELECTION', field + ' = 1')
        except Exception as e:
            arcpy.AddWarning(e)


def createbarrierlayers(datasets, element):
    count = 0
    layers = []
    for setting in element.findall('Barrier'):
        try:
            for dataset in datasets:
                if arcpy.Exists(fileunion(dataset, gettext(setting))):
                    barrier = fileunion(dataset, gettext(setting))
            layer = 'barrier' + str(count)
            createlayerwithreps(barrier, layer, getattribute(setting, 'query'), getattribute(setting, 'reps'))
            layers.append((layer, getattribute(setting, 'orient'), getattribute(setting, 'gap')))
            count += 1
        except Exception as e:
            arcpy.AddWarning(e)
    return layers


def deletebarrierlayers(barrierlayers):
    for barrier in barrierlayers:
        try:
            delete(barrier[0])
        except Exception as e:
            arcpy.AddWarning(e)


def makebarrierstring(barrierlayers):
    barrier_string = ''
    count = 0
    for barrier in barrierlayers:
        try:
            if not count == 0:
                barrier_string += ';'
            layer = barrier[0]
            orient = barrier[1]
            gap = "'" + barrier[2] + "'"
            barrier_string += layer + ' ' + orient + ' ' + gap
            count += 1
        except Exception as e:
            arcpy.AddWarning(e)
    return barrier_string


def createbuildingslayers(datasets, element, invisibilityfield):
    count = 0
    layers = []
    for setting in element.findall('Building'):
        try:
            for dataset in datasets:
                if arcpy.Exists(fileunion(dataset, gettext(setting))):
                    building = fileunion(dataset, gettext(setting))
            layer = 'building' + str(count)
            addfieldvisibilityfield(building, invisibilityfield)
            createlayerwithreps(building, layer, getattribute(setting, 'query'), getattribute(setting, 'reps'))
            layers.append(layer)
            count += 1
        except Exception as e:
            arcpy.AddWarning(e)
    return layers


def deletebuildingslayers(buildingslayers):
    for building in buildingslayers:
        try:
            delete(building)
        except Exception as e:
            arcpy.AddWarning(e)


def makebuildingstring(buildinglayers):
    building_string = ''
    count = 0
    for building in buildinglayers:
        try:
            if not count == 0:
                building_string += ';'
            building_string += building
            count += 1
        except Exception as e:
            arcpy.AddWarning(e)
    return building_string


# Utility Functions
def createlayer(featureclass, outlayer, query):
    try:
        delete(outlayer)
        arcpy.management.MakeFeatureLayer(featureclass, outlayer, query)
    except Exception as e:
        arcpy.AddWarning(e)


def createlayerwithreps(featureclass, outlayer, query, reps):
    try:
        createlayer(featureclass, outlayer, query)
        arcpy.cartography.SetLayerRepresentation(outlayer, reps)
    except Exception as e:
        arcpy.AddWarning(e)


def delete(arcobject):
    try:
        arcpy.management.Delete(arcobject, '#')
    except Exception as e:
        arcpy.AddWarning(e)


def fileunion(dataset, featureclass):
    return dataset + '\\' + featureclass


def fieldexists(featureclass, field):
    try:
        fields = arcpy.ListFields(featureclass, field)
        if fields.count == 1:
            return True
        else:
            return False
    except Exception as e:
        arcpy.AddWarning(e)


def getdistance(element):
    try:
        distance = gettext(element)
        search_units = getattribute(element, 'units')
        return distance + ' ' + search_units
    except Exception as e:
        arcpy.AddWarning(e)


# XAML Utility Functions
def getelement(element, tag):
    return element.findall(tag)[0]


def getattribute(element, attribute):
    return element.attrib[attribute]


def gettext(element):
    return element.text


def main():
    try:
        file_name = arcpy.GetParameterAsText(0)
        datasets = arcpy.GetParameterAsText(1).split(';')
        coordinate = arcpy.GetParameterAsText(2)

        tree = Tree.ElementTree(file=file_name)
        settings = tree.getroot()

        version = getattribute(settings, 'version')
        if version == '10.2.0.0':
            scale = getattribute(settings, 'referenceScale')
            arcpy.env.referenceScale = scale
            arcpy.env.cartographicCoordinateSystem = coordinate
            arcpy.AddMessage('Aligning Markers...')
            executealignmarkers(datasets, settings)
            arcpy.AddMessage('Calculating Hierarchies...')
            executecalculatehierarchies(datasets, settings)
            arcpy.AddMessage('Resolving Building Conflicts...')
            output = executeresolvebuildingconflicts(datasets, settings)
            arcpy.SetParameterAsText(3, output)
            del scale
        else:
            arcpy.AddError('XML version does not match the tool.')
    except Exception as e:
        arcpy.AddError(e)
        arcpy.AddError('Error encountered. Process did not complete successfully.')
    finally:
        del file_name, datasets, coordinate, tree, settings, version


if __name__ == '__main__':
    main()
