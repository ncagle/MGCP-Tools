# COPYRIGHT 2017 ESRI
#
# TRADE SECRETS: ESRI PROPRIETARY AND CONFIDENTIAL
# Unpublished material - all rights reserved under the
# Copyright Laws of the United States.
#
# For additional information, contact:
# Environmental Systems Research Institute, Inc.
# Attn: Contracts Dept
# 380 New York Street
# Redlands, California, USA 92373
#
# email: contracts@esri.com

import arcpy


def RemapId(inputId, idRemap):
    nextId =  idRemap[inputId]
    curId = inputId
    while nextId != curId:
        curId = nextId
        nextId = idRemap[curId]
    return nextId


def GetUpdateFeature(featureId, featureClass):
    return arcpy.UpdateCursor(featureClass, "OBJECTID = " + str(featureId))


def GetSearchFeature(featureId, featureClass):
    return arcpy.SearchCursor(featureClass, "OBJECTID = " + str(featureId))


def GeomClosed(geometry):
    first = geometry.firstPoint
    last = geometry.lastPoint
    if (first.X, first.Y) == (last.X, last.Y):
        return True
    else:
        return False


def GeomToArray(geometry):
    geom = []
    for part in geometry:
        for pnt in part:
            geom.append(pnt)
    return geom


def MergeClosed(geometry1, geometry2):
    mergeGeometry = []
    lenGeom1 = len(geometry1)
    lenGeom2 = len(geometry2)
    segment1 = (geometry1[lenGeom1-1],geometry2[lenGeom2-1])
    segment2 = (geometry1[0],geometry2[0])
    if not SegmentsCross(segment1,segment2):
        geometry2.reverse()
        mergeGeometry.append(geometry2[lenGeom2-1])
        mergeGeometry.extend(geometry1)
        mergeGeometry.extend(geometry2)
    else:
        segment1 = (geometry1[lenGeom1-1],geometry2[0])
        segment2 = (geometry1[0],geometry2[lenGeom2-1])
        if not SegmentsCross(segment1,segment2):
            mergeGeometry.append(geometry2[lenGeom2-1])
            mergeGeometry.extend(geometry1)
            mergeGeometry.extend(geometry2)
    return mergeGeometry


def MergeOpen(geometry1, geometry2):
    mergeGeometry = []
    lenGeom1 = len(geometry1)
    lenGeom2_0 = len(geometry2[0])
    lenGeom2_1 = len(geometry2[1])
    if lenGeom1 > 0 and lenGeom2_0 > 0 and lenGeom2_1 > 0:
        segment1 = (geometry1[lenGeom1-1],geometry2[1][0])
        segment2 = (geometry1[0],geometry2[0][lenGeom2_0-1])
        if not SegmentsCross(segment1,segment2):
            mergeGeometry.extend(geometry2[0])
            mergeGeometry.extend(geometry1)
            mergeGeometry.extend(geometry2[1])
        else:
            segment1 = (geometry1[0],geometry2[1][0])
            segment2 = (geometry1[lenGeom1-1],geometry2[0][lenGeom2_0-1])
            if not SegmentsCross(segment1,segment2):
                geometry1.reverse()
                mergeGeometry.extend(geometry2[0])
                mergeGeometry.extend(geometry1)
                mergeGeometry.extend(geometry2[1])
    return mergeGeometry


def Single(geometry, removals):
    mergeGeometry = []
    double = Double(geometry, removals)
    if not len(double[1]) == 0:
        double[1].pop()
    mergeGeometry.extend(double[1])
    mergeGeometry.extend(double[0])
    return mergeGeometry


def Double(geometry, removals):
    count = 0
    left = []
    right = []
    foundSplit = False
    for pnt in geometry:
        if not count in removals:
            if not foundSplit:
                left.append(pnt)
            else:
                right.append(pnt)
        else:
            foundSplit = True
        count += 1
    return (left,right)


def PointToString(point):
    return (point.X, point.Y)


def SegmentsCross(segment1, segment2):
    x1 = segment1[0].X
    x2 = segment1[1].X
    x3 = segment2[0].X
    x4 = segment2[1].X

    y1 = segment1[0].Y
    y2 = segment1[1].Y
    y3 = segment2[0].Y
    y4 = segment2[1].Y

    d = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4)
    if d == 0 :
        return False

    pre = (x1*y2 - y1*x2)
    post = (x3*y4 - y3*x4)
    x = ( pre * (x3 - x4) - (x1 - x2) * post ) / d
    y = ( pre * (y3 - y4) - (y1 - y2) * post ) / d
    #get spatial Tolerance
    if x < min(x1, x2) or x > max(x1, x2) or x < min(x3, x4) or x > max(x3, x4):
        return False
    if y < min(y1, y2) or y > max(y1, y2) or y < min(y3, y4) or y > max(y3, y4):
        return False
    return True


def GetGeometryRemovals(geometry1, geometry2):
    pointDictionary = dict()
    geometry1Removals = set()
    geometry2Removals = set()

    pointCount = 0
    for pnt in geometry1:
        match = pointDictionary.get(PointToString(pnt))
        if not match is None:
            match.append(pointCount)
        else:
            pointDictionary[PointToString(pnt)] = [pointCount]
        pointCount += 1

    pointCount = 0
    for pnt in geometry2:
        match = pointDictionary.get(PointToString(pnt))
        if not match is None:
            geometry1Removals.update(set(match))
            geometry2Removals.add(pointCount)
        pointCount += 1
    return (geometry1Removals, geometry2Removals)


def MergeGeometry(featureClass, featureId1, featureId2, geometry1, geometry2):
    retGeometry = ManualMergeGeometry(geometry1, geometry2)
    if retGeometry == None:
        arcpy.MakeFeatureLayer_management(featureClass, SymmDiffLayer1, "OBJECTID = " + featureId1, "", "#")
        arcpy.MakeFeatureLayer_management(featureClass, SymmDiffLayer2, + "OBJECTID = " + featureId2, "", "#")
        arcpy.SymDiff_analysis(SymmDiffLayer1,SymmDiffLayer2,SymDiff,"ONLY_FID","#")
        arcpy.Dissolve_management(SymDiff,Dissolve1,"#","#","SINGLE_PART","UNSPLIT_LINES")

        rows = UpdateCursor(Dissolve1)
        row = None
        for row in rows:
            if row.shape.pointCount <= 3:
                rows.deleteRow(row)
        del rows
        if not row == None:
            del row

        arcpy.Dissolve_management(Dissolve1,Dissolve2,"#","#","SINGLE_PART","UNSPLIT_LINES")
        if int(arcpy.GetCount_management(Dissolve2)) == 1:
            rows = SearchCursor(Dissolve2)
            row = rows.next()
            retGeometry = row.Shape
            del rows
            if not row == None:
                del row
        else:
            retGeometry = None
    return retGeometry


def ManualMergeGeometry(geometry1, geometry2):
    isGeom1Closed = GeomClosed(geometry1)
    isGeom2Closed = GeomClosed(geometry2)

    if isGeom1Closed == False and isGeom2Closed == False:
        return None

    geom1 = GeomToArray(geometry1)
    geom2 = GeomToArray(geometry2)

    geomRemovals = GetGeometryRemovals(geom1,geom2)
    geom1Removals = geomRemovals[0]
    geom2Removals = geomRemovals[1]

    if len(geom1Removals) == 0 or len(geom2Removals) == 0:
        return None

    single1 = None
    double1 = None
    single2 = None
    double2 = None

    if isGeom1Closed:
        single1 = Single(geom1,geom1Removals)
    else:
        double1 = Double(geom1,geom1Removals)
    if isGeom2Closed:
        single2 = Single(geom2,geom2Removals)
    else:
        double2 = Double(geom2,geom2Removals)

    mergedGeometry = None
    if isGeom1Closed:
        if isGeom2Closed:
            mergedGeometry = MergeClosed(single1,single2)
        else:
            mergedGeometry = MergeOpen(single1,double2)
    else:
        if isGeom2Closed:
            mergedGeometry = MergeOpen(single2,double1)

    if not mergedGeometry == None:
        geometryOutput = arcpy.Array()
        for pnt in mergedGeometry:
            pnt.ID = 0
            geometryOutput.add(pnt)
        return geometryOutput
    else:
        return None


def MergeFeatures(featureClass, featureId1, featureId2, row1, row2):
    try:
        mergedGeometry = MergeGeometry(featureClass, featureId1, featureId2, row1.shape, row2.shape)
        if not mergedGeometry == None:
            row1.shape = mergedGeometry
            return True
        else:
            return False
    except Exception as e:
        return False


def MergeContours(contours, tolerance, scratchWorkspace):
    try:
        #contours = arcpy.GetParameterAsText(0)
        #tolerance = arcpy.GetParameterAsText(1)
        #scratchWorkspace = arcpy.GetParameterAsText(2)
        arcpy.env.overwriteOutput = 1

        InputLayerSel = "ContourSelect"
        InputLayer = "Contour"
        Closed = scratchWorkspace + "\\Closed"
        ContourSpatialJoin = scratchWorkspace + "\\ContourL_SpatialJoin1"
        ContourSpatialJoinLayer = "ContourSpatialJoinLayer"
        SymmDiffLayer1 = "SymDiff1"
        SymmDiffLayer2 = "SymDiff2"
        SymDiff = scratchWorkspace + "\\SymmetricDifference"
        Dissolve1 = scratchWorkspace + "\\Dissolve1"
        Dissolve2 = scratchWorkspace + "\\Dissolve2"

        minLength = (pow(float(tolerance)*100,2)/50)+(float(tolerance)*10)

        spatialRef = arcpy.SpatialReference()
        spatialRef.factoryCode = 4326
        spatialRef.create()

        objectIds = []
        row = None
        rows = arcpy.SearchCursor(contours,"",spatialRef)
        for row in rows:
            if GeomClosed(row.shape) and row.shape.length <= minLength:
                    objectIds.append(row.OBJECTID)
        if not row is None:
            del row
        del rows

        clause = "OBJECTID IN " + str(objectIds).replace("[", "(").replace("]", ")")

        arcpy.MakeFeatureLayer_management(contours, InputLayerSel, clause, "", "#")
        arcpy.MakeFeatureLayer_management(contours, InputLayer, "", "", "#")

        arcpy.SpatialJoin_analysis(InputLayerSel, InputLayer, ContourSpatialJoin, "JOIN_ONE_TO_MANY", "KEEP_COMMON", "#", "INTERSECT", "", "")
        arcpy.MakeFeatureLayer_management(ContourSpatialJoin, ContourSpatialJoinLayer, "TARGET_FID <> JOIN_FID", "", "#")

        rows = arcpy.SearchCursor(ContourSpatialJoinLayer)

        #dictionary of tuples to find unique mappings of fids
        featureIdMapLR = dict()
        featureIdRemap = dict()
        row = None
        for row in rows:
            id1 = min(row.TARGET_FID, row.JOIN_FID)
            id2 = max(row.TARGET_FID, row.JOIN_FID)
            if featureIdMapLR.has_key(id1):
                featureIdMapLR.get(id1).add(id2)
            else:
                featureIdMapLR[id1] = set([id2])
            featureIdRemap[id1] = id1
            featureIdRemap[id2] = id2
        if not row is None:
            del row
        del rows

        removalList = set()
        for item in featureIdMapLR.items():
            lid = item[0]
            lidRemap = RemapId(lid,featureIdRemap)
            featureLCursor = GetUpdateFeature(lidRemap, contours)
            featureL = featureLCursor.next()
            while len(item[1]) != 0:
                gid = item[1].pop()
                gidRemap = RemapId(gid,featureIdRemap)
                if gidRemap != lidRemap:
                    featureRCursor = GetSearchFeature(gidRemap,contours)
                    featureR = featureRCursor.next()
                    success = MergeFeatures(contours, lidRemap, gidRemap, featureL, featureR)
                    if success:
                        featureLCursor.updateRow(featureL)
                        if featureIdMapLR.has_key(gidRemap):
                            item[1].update(featureIdMapLR[gidRemap])
                            del featureIdMapLR[gidRemap]
                        featureIdRemap[gidRemap] = lidRemap
                        removalList.add(gid)
                    del featureRCursor
                    del featureR
            del featureLCursor
            del featureL
        for id in removalList:
            featureCursor = GetUpdateFeature(id, contours)
            feature = featureCursor.next()
            featureCursor.deleteRow(feature)
            del featureCursor
            del feature
    except Exception as e:
        arcpy.AddMessage("Error Encountered while merging.")


def CleanupTags(contours, outputFeatureClass):
    try:
        arcpy.env.overwriteOutput = 1
        arcpy.Dissolve_management(contours,outputFeatureClass,["Contour"],"#","SINGLE_PART","UNSPLIT_LINES")
    except Exception as e:
        arcpy.AddMessage("Error Encountered while removing tags.")