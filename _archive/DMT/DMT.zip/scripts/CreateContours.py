# ----------------------------------------------------------------------------------------------------------------------
# COPYRIGHT 2017 ESRI
#
# TRADE SECRETS: ESRI PROPRIETARY AND CONFIDENTIAL
# Unpublished material - all rights reserved under the
# Copyright Laws of the United States.
#
# For additional information, contact:
# Environmental Systems Research Institute, Inc.
# Attn: Contracts Dept
# 380 New York Street
# Redlands, California, USA 92373
#
# email: contracts@esri.com
# ----------------------------------------------------------------------------------------------------------------------

# ----------------------------------------------------------------------------------------------------------------------
# Usage notes
# CreateContours_defense(Input_Raster;Input_Raster...,
# 1:50000 | 1:5000 | 1:7500 | 1:12500 | 1:25000 | 1:100000 | 1:250000 | 1:500000 | 1:1000000,
# Base_Contour, Contour_Interval, Index_Interval, NO_INCLUDE_ZERO_CONTOUR | INCLUDE_ZERO_CONTOUR,
# Out_Contour_Features, Contour_Subtype, {Input_Area_of_Interest})
#
# INDEX, NAME, DISPLAY NAME, PARAMETER TYPE, MULTIVALUE, DATA TYPE, DIRECTION, DEPENDENCIES, VALUE
# {0}, Input_Raster, Input Raster, Required, True, Raster Layer, Input, [], None
# {1}, Map_Scale, Map Scale, Required, False, String, Input, [], 1:50000
# {2}, Base_Contour, Base Contour, Required, False, Double, Input, [], 0.0
# {3}, Contour_Interval, Contour Interval, Required, False, Double, Input, [], None
# {4}, Index_Interval, Index Interval, Required, False, Double, Input, [], 100.0
# {5}, Include_Zero_Contour, Include Zero Contour, Required, False, Boolean, Input, [], False
# {6}, Out_Contour_Features, Out Contour Features, Required, False, Feature Layer, Input, [], None
# {7}, Contour_Subtype, Contour Subtype, Required, False, String, Input, [], None
# {8}, Input_Area_of_Interest, Input Area of Interest, Optional, False, Feature Layer, Input, [], None
# {9}, Raster_Elevation_Units, Raster Elevation Units, Optional, False, String, Input, [], None
# {10}, Contour_Elevation_Units, Contour Elevation Units, Optional, False, String, Input, [], None
# {11}, Resample_Raster, Resample Raster, Optional, False, Boolean, Input, [], RESAMPLE
# {12}, Contours, Contours, Derived, False, Feature Layer, Output, [6], None
# ----------------------------------------------------------------------------------------------------------------------

# Providing a variable with the file name
THIS_FILE_NAME = 'CreateContours.py'


# Setting up the environment for the script
def setupenv():
    from arcpy import AddMessage
    from DefenseUtilities import setenvironment
    scratch, tempfolder, templist = setenvironment()
    AddMessage('Scratch Workspace: {0}'.format(scratch))
    return scratch, tempfolder, templist


# Setting up temp features
def setuptempfeatures(scale, scratch):
    from DefenseUtilities import GetContourTolerances
    resample = r'{0}\Resample'.format(scratch)
    mosaic = 'TempRaster'
    temp0 = r'{0}\TempPoly0'.format(scratch)
    temp1 = r'{0}\TempPoly1'.format(scratch)
    tol = GetContourTolerances(scale)
    minlength = tol.minimumLength
    return resample, mosaic, temp0, temp1, minlength


# Getting information from the rasters
def getrastercell(rasterlist):
    from arcpy import management, AddError
    from DefenseUtilities import GetRasterProperties
    from string import split, strip
    from locale import atof
    currastercellsizex = None
    currastercellsizey = None
    currasterbandcount = None
    currasterpixeltype = None
    rasterprops = None
    rastercellsizex = ''
    for raster in split(rasterlist, ';'):
        raster = r'{0}'.format(strip(raster, "'"))
        rastercellsizex = management.GetRasterProperties(raster, 'CELLSIZEX')
        rastercellsizey = management.GetRasterProperties(raster, 'CELLSIZEY')
        rasterbandcount = management.GetRasterProperties(raster, 'BANDCOUNT')
        rasterpixeltype = management.GetRasterProperties(raster, 'VALUETYPE')
        if currastercellsizex is not None and currastercellsizey is not None and\
           currasterbandcount is not None and currasterpixeltype is not None:
            if currastercellsizex.getOutput(0) != rastercellsizex.getOutput(0) or\
               currastercellsizey.getOutput(0) != rastercellsizey.getOutput(0) or\
               currasterbandcount.getOutput(0) != rasterbandcount.getOutput(0) or\
               currasterpixeltype.getOutput(0) != rasterpixeltype.getOutput(0):
                AddError('Rasters have incompatible CellSize, BandCount or PixelTypes')
                raise Exception('Create Contours Error')
        currastercellsizex = rastercellsizex
        currastercellsizey = rastercellsizey
        currasterbandcount = rasterbandcount
        currasterpixeltype = rasterpixeltype
        rasterprops = GetRasterProperties([raster])
    return rasterprops, atof(str(rastercellsizex))


# Mosaicing Raster
def mosaicraster(rasterlist, scratch, mosaicname, rasterprops, resampleraster, inputaoi, rastercellsizex, resample):
    from arcpy import AddMessage, management, analysis
    from string import split, strip
    from locale import atof
    if len(split(rasterlist, ';')) > 1:
        AddMessage('Creating Mosaic')
        management.MosaicToNewRaster(rasterlist, scratch, mosaicname, '#', rasterprops.pixelType, '#',
                                     rasterprops.bands, 'MEAN', 'FIRST')
        inputraster = r'{0}\{1}'.format(scratch, mosaicname)
    else:
        inputraster = r'{0}'.format(strip(rasterlist, "'"))
    if inputaoi == '' or inputaoi == '#' or inputaoi is None:
        pass
    else:
        management.Clip(inputraster, '#', r'{0}\{1}'.format(scratch, 'Test_Raster'), inputaoi, '#', 'NONE',
                        'MAINTAIN_EXTENT')
        isnull = management.GetRasterProperties(r'{0}\{1}'.format(scratch, 'Test_Raster'), 'ALLNODATA').getOutput(0)
        if isnull == '1':
            raise Exception('There is no raster data for the specified AOI.')
        else:
            management.CopyFeatures(inputaoi, r'{0}\{1}'.format(scratch, 'AOI_Copy'))
            analysis.Buffer(r'{0}\{1}'.format(scratch, 'AOI_Copy'), r'{0}\{1}'.format(scratch, 'Buffer_Poly'),
                            '5 Kilometers')
            management.Merge([r'{0}\{1}'.format(scratch, 'AOI_Copy'), r'{0}\{1}'.format(scratch, 'Buffer_Poly')],
                             r'{0}\{1}'.format(scratch, 'AOI_Buffer_Merge'))
            management.MakeFeatureLayer(r'{0}\{1}'.format(scratch, 'AOI_Buffer_Merge'), 'Merge')
            management.SelectLayerByAttribute('Merge', 'NEW_SELECTION')
            management.Eliminate('Merge', r'{0}\{1}'.format(scratch, 'Eliminate_AOI'))
            management.MakeRasterLayer(inputraster, 'RasterLayer')
            management.Clip(inputraster, '#', r'{0}\{1}'.format(scratch, 'Clip_Raster'), 'Merge', '#', 'ClippingGeometry',
                            'MAINTAIN_EXTENT')
            management.CopyRaster(r'{0}\{1}'.format(scratch, 'Clip_Raster'), r'{0}\{1}'.format(scratch, 'Final_Raster'),
                                  '#', '#', '#', 'NONE', 'NONE', '32_BIT_UNSIGNED', 'NONE', 'NONE')
            inputraster = r'{0}\{1}'.format(scratch, 'Final_Raster')

    if resample == 'true':
        AddMessage('Resampling raster...')
        management.Resample(inputraster, resampleraster, atof(str(rastercellsizex/4)), 'BILINEAR')
        return resampleraster
    else:
        return inputraster


# Running the processes for contours
def runcontours(basecontour, contourinterval, includezero, resampleraster, temppoly0, temppoly1, minlen, zfactor):
    from arcpy import AddMessage, management, sa, da, defense, SpatialReference, UpdateCursor
    from DefenseUtilities import cleanup
    from MergeContours import CleanupTags
    AddMessage('Creating contours...')
    sa.Contour(resampleraster, temppoly0, contourinterval, basecontour, zfactor)
    AddMessage('Repairing contours...')
    management.RepairGeometry(temppoly0, 'DELETE_NULL')
    AddMessage('Smoothing contours...')
    defense.SmoothLine(temppoly0)
    AddMessage('Reconnecting contours...')
    CleanupTags(temppoly0, temppoly1)
    cleanup([temppoly0])
    spatialref = SpatialReference()
    spatialref.factoryCode = 4326
    spatialref.create()
    row = None
    rows = UpdateCursor(temppoly1, '', spatialref)
    for row in rows:
        if row.shape.length <= minlen:
            rows.deleteRow(row)
    if row is not None:
        del row
    del rows
    if includezero == 'false':
        AddMessage('Removing zero contour...')
        rows = da.UpdateCursor(temppoly1, ['Contour'])
        for row in rows:
            if row[0] == 0:
                rows.deleteRow()
        if row is not None:
            del row
        del rows
    return temppoly1


# Updating fields on Contours
def updatefields(templines, outputlines, subtype):
    from arcpy import AddMessage, AddWarning, management, Describe, UpdateCursor
    from DefenseUtilities import cleanup, fieldexists
    AddMessage('Calculating fields...')
    path = Describe(templines).CatalogPath
    fieldzvh = fieldexists(outputlines, u'ZVH')
    fieldZV2 = fieldexists(outputlines, u'ZV2')
    fieldzv2 = fieldexists(outputlines, u'zv2')
    if fieldzvh:
        hfield = 'ZVH'
        fieldmapping = """ZVH "Highest Elevation" true false false 8 Double 0 0, First, #, {0}, Contour,""".format(path) + \
                       """ -1, -1; SHAPE_Length "SHAPE_Length" false true true 8 Double 0 0, First, #, {0},""".format(path) + \
                       """Shape_Length, -1, -1"""
    elif fieldZV2 or fieldzv2:
        if fieldzv2:
            hfield = 'ZV2'
        else:
            hfield = 'zv2'
        fieldmapping = """ZV2 "Highest Z-Value" true false false 8 Double 0 0, First, #, {0}, Contour, """.format(path) + \
                       """-1, -1; SHAPE_Length "SHAPE_Length" false true true 8 Double 0 0, First, #, {0}, """.format(path) + \
                       """Shape_Length, -1, -1"""
    else:
        hfield = 'ZVH'
        AddWarning('The feature class schema is not a supported schema, adding proper fields to the feature class...')
        management.AddField(outputlines, 'ZVH', 'DOUBLE', '', '', '', 'Highest Elevation', '', '', '')
        management.AddField(outputlines, 'F_CODE', 'TEXT', '', '', '', 'Feature Code', '', '', '')
        management.AddField(outputlines, 'HQC', 'DOUBLE', '', '', '', 'Hypsography Portrayal Type', '', '', '')
        management.AddField(outputlines, 'FCSubtype', 'LONG', '', '', '', 'Feature Class Subtype', '', '', '')
        fieldmapping = """ZVH "Highest Elevation" true false false 8 Double 0 0, First, #, {0}, Contour,""".format(path) + \
                       """ -1, -1; SHAPE_Length "SHAPE_Length" false true true 8 Double 0 0 , First, #, {0},""".format(path) + \
                       """Shape_Length, -1, -1 """
    try:
        AddMessage('Updating {0}...'.format(outputlines))
        management.Append(templines, outputlines, 'NO_TEST', fieldmapping, subtype)
        cleanup([templines])
    except Exception as e:
        from arcpy import AddError
        AddError('Unable to append features to the feature class.\n{0}'.format(e))
    ESCfieldexists = fieldexists(outputlines, u'ESC')
    escfieldexists = fieldexists(outputlines, u'esc')
    rows = UpdateCursor(outputlines)
    for row in rows:
        if ESCfieldexists:
            row.ESC = 1
        if escfieldexists:
            row.esc = 1
        rows.updateRow(row)
    if row is not None:
        del row
    del rows
    return outputlines, hfield


# Coding contours
def codecontours(outputpolylines, field, interval, inputraster):
    from arcpy import AddMessage, SetParameter, defense
    AddMessage('Calculating default attribute values...')
    defense.CalculateDefaultValues(outputpolylines)
    AddMessage('Coding contours...')
    defense.CodeContours(outputpolylines, field, interval, inputraster)
    SetParameter(12, outputpolylines)
    return

def getzfactor(raster_units, contour_units):
    if not raster_units or not contour_units:
        return "1" #if either one is not defined no conversion
    if raster_units.lower() == "meters":
        if contour_units.lower() == "feet":
            return "3.2808"
        else:
            return "1"
    elif raster_units.lower() == "feet":
        if contour_units.lower() == "meters":
            return "0.3048"
        else:
            return "1"
    else:
        return "1"

# Main execution
def main():
    from arcpy import GetParameterAsText
    from DefenseUtilities import checkoutextensions
    from locale import atof
    try:
        checkoutextensions(['spatial', 'defense'])
        scratch, tempfolder, templistplist = setupenv()
        resampleraster, mosaicrastername, templines0, templines1, minlength = setuptempfeatures(
            GetParameterAsText(1), scratch)
        rasterprops, rastercellsizex = getrastercell(GetParameterAsText(0))
        inputraster = mosaicraster(GetParameterAsText(0), scratch, mosaicrastername, rasterprops, resampleraster,
                                   GetParameterAsText(8), rastercellsizex, GetParameterAsText(11))
        zfactor = getzfactor(GetParameterAsText(9), GetParameterAsText(10))
        templines2 = runcontours(atof(str(GetParameterAsText(2))), atof(str(GetParameterAsText(3))), GetParameterAsText(5),
                                 inputraster, templines0, templines1, minlength, zfactor)
        outputpolylines, hfield = updatefields(templines2, GetParameterAsText(6), GetParameterAsText(7))
        codecontours(outputpolylines, hfield, atof(str(GetParameterAsText(4))), inputraster)
    except Exception as e:
        from arcpy import AddError
        from DefenseUtilities import trace
        line, filename, err = trace(THIS_FILE_NAME)
        AddError('Geoprocessing error on {0} of {1} :\n{2}\n{3}'.format(line, filename, err, e))
    finally:
        from os import path
        from shutil import rmtree
        try:
            folder = path.split(scratch)[0]
            rmtree(folder, True)
        except Exception as e:
            pass

# Run main
if __name__ == '__main__':
    main()
