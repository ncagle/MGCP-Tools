# COPYRIGHT 2017 ESRI
#
# TRADE SECRETS: ESRI PROPRIETARY AND CONFIDENTIAL
# Unpublished material - all rights reserved under the
# Copyright Laws of the United States.
#
# For additional information, contact:
# Environmental Systems Research Institute, Inc.
# Attn: Contracts Dept
# 380 New York Street
# Redlands, California, USA 92373
#
# email: contracts@esri.com

#-------------------------------------------------------------------------------
# Usage notes
# UnzipCellAndImport_defense(Root_Folder, Target_Geodatabase)
#
# INDEX, NAME, DISPLAY NAME, PARAMETER TYPE, MULTIVALUE, DATA TYPE, DIRECTION, DEPENDENCIES, VALUE
# {0}, Root_Folder, Root Folder, Required, False, Folder, Input, [], None
# {1}, Target_Geodatabase, Target Geodatabase, Required, False, Workspace, Input, [], None
# {2}, Output_Geodatabase, Output Geodatabase, Derived, False, Workspace, Output, [], None
#-------------------------------------------------------------------------------

"""

Tool Name: Unzip And Import
Source Name: UnzipAndImport.py
Version: ArcGIS 10.3.1
Author: ESRI

This script recursively searches a root folder for zipped archives of MGCP
shapefiles and metadata, unzips them and ingests the data into a target
geodatabase.

"""

import arcpy, sys, os, zipfile, re, glob, DefenseUtilities


# Unzips an archive to a target location
def unzip(zip_path, target):
    if not os.path.isdir(target):
        os.makedirs(target)

    baseDir = ""
    archive = zipfile.ZipFile(zip_path, 'r')

    try:
        for name in archive.namelist():
            if not name.endswith('/'):
                root, fname = os.path.split(name)
                directory = os.path.normpath(os.path.join(target, root))
                if not os.path.isdir(directory):
                    os.makedirs(directory)
                if len(baseDir) == 0:
                    baseDir = directory
                archive.extract(name, directory)
    finally:
        if archive:
            archive.close()


# Adds external tool messages to the messages of this tool
def addMessages():
    i = 0
    count = arcpy.GetMessageCount()
    while i < count:
        message = "    " + arcpy.GetMessage(i)
        severity = arcpy.GetSeverity(i)
        if severity == 1:
            arcpy.AddWarning(message)
        elif severity == 2:
            arcpy.AddError(message)
        else:
            arcpy.AddMessage(message)
        i += 1


def cleanUp(extractFolder):
    # Clean up extracted shapefiles
    arcpy.AddMessage("Cleaning up extracted shapefiles in %s" % extractFolder)
    arcpy.env.workspace = extractFolder
    shapefiles = arcpy.ListFeatureClasses()
    for s in shapefiles:
        try:
            arcpy.Delete_management(s)
        except arcpy.ExecuteError:
            arcpy.AddWarning("Failed to delete {0}.\r\n{1}".format(s, arcpy.GetMessages(2)))

    # Clean up any other files
    files = arcpy.ListFiles()
    for f in files:
        try:
            arcpy.Delete_management(f)
        except arcpy.ExecuteError:
            arcpy.AddWarning("Failed to delete {0}.\r\n{1}".format(f, arcpy.GetMessages(2)))


def validateTargetGdb(gdbPath):
    arcpy.AddMessage('Validating target geodatabase...')
    if not arcpy.Exists(gdbPath):
        arcpy.AddError('{0} does not exist.'.format(gdbPath))
        return False, ''
    desc = arcpy.Describe(gdbPath)
    if desc.dataType != 'Workspace':
        arcpy.AddError('{0} is not a workspace.'.format(gdbPath))
        return False, ''
    del desc
    arcpy.env.workspace = gdbPath
    mgcpMetadataFeatureDataset = gdbPath
    featureDatasetList = arcpy.ListDatasets('*MGCP_Metadata', 'Feature')
    if len(featureDatasetList) > 0:
        mgcpMetadataFeatureDataset = os.path.join(mgcpMetadataFeatureDataset, featureDatasetList[0])
    else:
        arcpy.AddError('MGCP_Metadata feature dataset not found.')
        return False, ''
    subregionFC = mgcpMetadataFeatureDataset
    subregionSearch = arcpy.ListFeatureClasses(wild_card='*Subregion', feature_dataset=featureDatasetList[0])
    if len(subregionSearch) > 0:
        subregionFC = os.path.join(subregionFC, subregionSearch[0])
    else:
        arcpy.AddError('Subregion feature class not found.')
        return False, ''
    if len(arcpy.ListFields(subregionFC, 'SVNAME')) > 0:
        if len(arcpy.ListFields(subregionFC, 'STIERN')) > 0:
            if len(arcpy.ListFields(subregionFC, 'SSVCTY')) > 0:
                # 4.1 and 4.2 are nearly identical, look at default value of SVSPCN
                specVal = ''
                try:
                    subtypes = arcpy.da.ListSubtypes(subregionFC)
                    for scode, dictInfo in subtypes.iteritems():
                        if scode == 0:
                            fields = dictInfo['FieldValues']
                            for field, fieldInfo in fields.iteritems():
                                if field.lower() == 'svspcn':
                                    specVal = fieldInfo[0]
                                    break
                            break
                    del subtypes
                except:
                    specVal = '4.1'
                if specVal.find('4.5') >= 0:
                    return True, '4.5'
                elif specVal.find('4.4') >= 0:
                    return True, '4.4'
                elif specVal.find('4.3') >= 0:
                    return True, '4.3'
                elif specVal.find('4.2') >= 0:
                    return True, '4.2'
                else:
                    return True, '4.1'
            else:
                return True, '4.0'
        else:
            return True, '3.0'
    else:
        cellFC = mgcpMetadataFeatureDataset
        cellSearch = arcpy.ListFeatureClasses(wild_card='*Cell', feature_dataset=featureDatasetList[0])
        if len(cellSearch) > 0:
            cellFC = os.path.join(cellFC, cellSearch[0])
            if len(arcpy.ListFields(cellFC, 'CVNAME')) > 0:
                return True, '2.0'
        arcpy.AddError('Unable to identify a valid TRD geodatabase schema.')
        return False, ''


def parseXmlVersion(metadataFilePath):
    # Using a simple character search for now
    stm = open(metadataFilePath)
    content = stm.read()
    stm.close()
    del stm
    # Find first <gmd:codeSpace> open tag
    codeSpaceOpenTag = '<gmd:codeSpace>'
    b = content.find(codeSpaceOpenTag)
    if b < 0:
        return ''
    # Find close tag
    e = content.find('</gmd:codeSpace>', b)
    if e < b:
        return ''
    charStringTag = content[b+len(codeSpaceOpenTag):e]
    b = charStringTag.find('>')
    if b < 0:
        return ''
    e = charStringTag.rfind('<')
    if e < b:
        return ''
    versionStr = charStringTag[b+1:e]

    if versionStr and len(versionStr) > 0:
        versionStr = versionStr.lower().strip()

        if versionStr == 'mgcp_v4_r5':
            return '4.5'
        elif versionStr == 'mgcp_v4_r4':
            return '4.4'
        elif versionStr == 'mgcp_v4_r3':
            return '4.3'
        elif versionStr == 'mgcp_v4_r2':
            return '4.2'
        elif versionStr == 'mgcp_v4_r1':
            return '4.1'
        elif versionStr == 'mgcp_v4_r0':
            return '4.0'
        elif versionStr == 'mgcp_v3_r0':
            return '3.0'
        elif versionStr == 'mgcp_v2_r0' or versionStr == 'mgcp_v1_r1':
            return '2.0'
    return ''


def parseVersionString(versionStr):
    i = versionStr.find('.')
    major = int(versionStr[0:i])
    minor = int(versionStr[i+1:])
    return major, minor


def versionsAreCompatible(xmlVersion, gdbVersion):
    xmlMajor = 0
    xmlMinor = 0
    gdbMajor = 0
    gdbMinor = 0

    try:
        xmlMajor, xmlMinor = parseVersionString(xmlVersion)
    except Exception as e:
        arcpy.AddError("Unable to parse xml version.")
        return False
    try:
        gdbMajor, gdbMinor = parseVersionString(gdbVersion)
    except Exception as e:
        arcpy.AddError("Unable to parse geodatabase version.")
        return False

    if xmlMajor < gdbMajor or (xmlMajor == gdbMajor and xmlMinor <= gdbMinor):
            return True

    return False


def main():
    # This is the folder that will be recursively searched
    root_folder = arcpy.GetParameterAsText(0)
    # The target MGCP geodatabase to ingest the data to
    target_gdb = arcpy.GetParameterAsText(1)

    # Derive the Cell feature class path from target geodatabase
    target_cell = os.path.join(target_gdb, "MGCP_Metadata\\Cell")

    # Get scratch folder to unzip the data to
    scratchFolder = arcpy.env.scratchFolder

    try:
        # Regex for matching xml metadata file names
        pattern = "[eEwW](0\d\d|1[0-7]\d|180)[nNsS]([0-8]\d|90).xml"
        regEx = re.compile(pattern)

        # Validate target geodatabase
        gdbIsValid, gdbVersion = validateTargetGdb(target_gdb)

        if gdbIsValid:
            arcpy.AddMessage("Target geodatabase TRD version: {0}".format(gdbVersion))
        else:
            return

        # Recursively walk the root folder
        for loc, dirs, files in os.walk(root_folder):
            for f in files:
                if f.lower().endswith(".zip"):
                    # Unzip the archive
                    fpath = os.path.join(loc, f)
                    arcpy.AddMessage("Found %s" % fpath)
                    arcpy.AddMessage("Extracting files to %s" % scratchFolder)
                    unzip(fpath, scratchFolder)

                    arcpy.AddMessage("Searching for metadata...")
                    xmlFiles = glob.glob(os.path.join(scratchFolder, '*.xml'))

                    metadataFile = ""

                    for x in xmlFiles:
                        m = regEx.match(os.path.basename(x))
                        if m:
                            arcpy.AddMessage("Found %s" % os.path.basename(x))
                            metadataFile = x
                            break

                    xmlVersion = ""

                    if metadataFile and len(metadataFile) > 0:
                        xmlVersion = parseXmlVersion(metadataFile)

                    if xmlVersion and len(xmlVersion) > 0:
                        arcpy.AddMessage("Shapefile TRD version: {0}".format(xmlVersion))
                    else:
                        arcpy.AddWarning("Unable to determine shapefile TRD version in {0}".format(f))
                        cleanUp(scratchFolder)
                        continue

                    if not versionsAreCompatible(xmlVersion, gdbVersion):
                        arcpy.AddWarning("Cannot process {0}, shapefile and geodatabase TRD versions are not compatible".format(x))
                        cleanUp(scratchFolder)
                        continue

                    defHome = DefenseUtilities.getproductpath()
                    crossRefDir = os.path.join(defHome, "Mgcp\\DataConversion")
                    crossRefName = "MGCP_TRD_{0}_SHP_to_MGCP_TRD_{1}_GDB.mdb".format(xmlVersion.replace(".", "_"), gdbVersion.replace(".", "_"))
                    if xmlVersion == "2.0" and gdbVersion == "3.0":
                        crossRefName = "MGCP_TRD_3_0_SHP_to_MGCP_TRD_3_0_GDB.mdb"
                    crossRefPath = os.path.join(crossRefDir, crossRefName)

                    if not arcpy.Exists(crossRefPath):
                        arcpy.AddWarning("Unable to find cross-reference database {0}".format(crossRefPath))
                        cleanUp(scratchFolder)
                        continue

                    # Load the shapefiles
                    arcpy.AddMessage("Loading shapefiles from %s" % scratchFolder)
                    try:
                        arcpy.LoadData_production(crossRefPath, scratchFolder, target_gdb)
                        addMessages()
                    except arcpy.ExecuteError:
                        arcpy.AddWarning("Failed to load shapefiles.\r\n{0}".format(arcpy.GetMessages(2)))
                        cleanUp(scratchFolder)
                        continue

                    # Import metdata
                    arcpy.AddMessage("Importing %s" % os.path.basename(metadataFile))
                    try:
                        arcpy.ImportMetadata_defense(metadataFile, target_cell)
                        addMessages()
                    except arcpy.ExecuteError:
                        arcpy.AddWarning("Failed to import {0}.\r\n{1}".format(os.path.basename(metadataFile), arcpy.GetMessages(2)))

                    for x in xmlFiles:
                        try:
                            arcpy.Delete_management(x)
                        except arcpy.ExecuteError:
                            arcpy.AddWarning("Failed to delete {0}.\r\n{1}".format(x, arcpy.GetMessages(2)))

                    # Clean up extracted files
                    cleanUp(scratchFolder)

        # Set the output parameter
        arcpy.SetParameter(2, target_gdb)
    except Exception as e:
        arcpy.AddError(e.message)


if __name__ == "__main__":
    main()
