# ----------------------------------------------------------------------------------------------------------------------
# COPYRIGHT 2017 ESRI
#
# TRADE SECRETS: ESRI PROPRIETARY AND CONFIDENTIAL
# Unpublished material - all rights reserved under the
# Copyright Laws of the United States.
#
# For additional information, contact:
# Environmental Systems Research Institute, Inc.
# Attn: Contracts Dept
# 380 New York Street
# Redlands, California, USA 92373
#
# email: contracts@esri.com
# ----------------------------------------------------------------------------------------------------------------------

# ----------------------------------------------------------------------------------------------------------------------
# Usage notes
# ExtractFiles_defense(Input_Zip_Folder, Output_Workspace)
#
# INDEX, NAME, DISPLAY NAME, PARAMETER TYPE, MULTIVALUE, DATA TYPE, DIRECTION, DEPENDENCIES, VALUE
# {0}, Input_Zip_Folder, Input Zip Folder, Required, False, File, Input, [], None
# {1}, Output_Workspace, Output Workspace, Required, False, Folder, Input, [], None
# {2}, Output_Location, Output Location, Derived, False, Folder, Output, [], None
# ----------------------------------------------------------------------------------------------------------------------

# Setting variable for file name
THIS_FILE_NAME = 'ExtractFiles.py'


# Extracts file from zipped folder
def extractfromzip(zippath, extractlocation):
    from zipfile import ZipFile
    from arcpy import SetParameter
    try:
        sourcezip = ZipFile(zippath, 'r')
        sourcezip.extractall(extractlocation)
        sourcezip.close()
        SetParameter(2, extractlocation)
        del sourcezip, zippath, extractlocation
        return
    except Exception as e:
        from arcpy import AddError
        from DefenseUtilities import trace
        line, filename, err = trace(THIS_FILE_NAME)
        AddError('Geoprocessing error on {0} of {1} :\n{2}\n{3}'.format(line, filename, err, e))


# Main execution
def main():
    from arcpy import GetParameterAsText
    from DefenseUtilities import setenvironment
    try:
        setenvironment()
        extractfromzip(GetParameterAsText(0), GetParameterAsText(1))
    except Exception as e:
        from arcpy import AddError
        from DefenseUtilities import trace
        line, filename, err = trace(THIS_FILE_NAME)
        AddError('Geoprocessing error on {0} of {1} :\n{2}\n{3}'.format(line, filename, err, e))


# Run main
if __name__ == '__main__':
    main()
